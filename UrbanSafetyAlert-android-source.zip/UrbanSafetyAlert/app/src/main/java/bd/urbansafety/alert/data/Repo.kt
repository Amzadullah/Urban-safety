package bd.urbansafety.alert.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.location.Geocoder
import android.net.Uri
import android.util.Base64
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Task
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

/** Single place that talks to Firebase and the Netlify functions. */
object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    private val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()
    private val reports get() = db.collection("reports")

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()
    private val aiHttp = http.newBuilder().callTimeout(25, TimeUnit.SECONDS).build()

    // ---------------- Auth ----------------

    suspend fun roleOf(uid: String): Role {
        val s = db.collection("users").document(uid).get().await()
        return if (s.getString("role") == Role.Authority.id) Role.Authority else Role.Citizen
    }

    suspend fun signIn(email: String, password: String) {
        auth.signInWithEmailAndPassword(email, password).await()
    }

    /** Creates the account and the users/{uid} doc (same shape as the website). Returns uid. */
    suspend fun signUp(email: String, password: String, role: Role): String {
        val res = auth.createUserWithEmailAndPassword(email, password).await()
        val uid = res.user?.uid ?: throw IllegalStateException("Account তৈরি হয়নি")
        db.collection("users").document(uid).set(
            mapOf("email" to email, "role" to role.id, "createdAt" to FieldValue.serverTimestamp())
        ).await()
        return uid
    }

    suspend fun sendPasswordReset(email: String) {
        auth.sendPasswordResetEmail(email).await()
    }

    fun signOut() = auth.signOut()

    /**
     * Google Play requires in-app account deletion. Re-authenticates, then deletes the user's
     * photos (Netlify Blobs), reports, profile doc and finally the Firebase Auth account.
     */
    suspend fun deleteAccount(password: String) {
        val u = auth.currentUser ?: throw IllegalStateException("আবার login করুন")
        val email = u.email ?: throw IllegalStateException("Email পাওয়া যায়নি")
        u.reauthenticate(EmailAuthProvider.getCredential(email, password)).await()

        // photos (best effort)
        runCatching {
            val token = u.getIdToken(true).await().token
            withContext(Dispatchers.IO) {
                val req = Request.Builder().url("${AppConfig.SITE}/api/photo")
                    .header("Authorization", "Bearer $token").delete().build()
                http.newCall(req).execute().close()
            }
        }

        val mine = reports.whereEqualTo("userId", u.uid).get().await().documents
        mine.chunked(400).forEach { chunk ->
            val batch = db.batch()
            chunk.forEach { batch.delete(it.reference) }
            batch.commit().await()
        }
        db.collection("users").document(u.uid).delete().await()
        u.delete().await()
    }

    // ---------------- Reports (live) ----------------

    fun myReports(uid: String): Flow<List<Report>> = callbackFlow {
        val reg = reports.whereEqualTo("userId", uid).addSnapshotListener { snap, err ->
            if (err != null) {
                close(err); return@addSnapshotListener
            }
            val list = snap?.documents.orEmpty().mapNotNull { Report.from(it) }
                .sortedByDescending { it.createdAt?.time ?: Long.MAX_VALUE }
            trySend(list)
        }
        awaitClose { reg.remove() }
    }

    fun allReports(): Flow<List<Report>> = callbackFlow {
        val reg = reports.orderBy("createdAt", Query.Direction.DESCENDING).addSnapshotListener { snap, err ->
            if (err != null) {
                close(err); return@addSnapshotListener
            }
            trySend(snap?.documents.orEmpty().mapNotNull { Report.from(it) })
        }
        awaitClose { reg.remove() }
    }

    /**
     * Firestore queues writes while offline and the Task only completes once the server
     * acknowledges it. Returns true if synced, false if it is queued for later.
     */
    private suspend fun <T> Task<T>.commit(): Boolean =
        withTimeoutOrNull(10_000L) { this@commit.await(); true } ?: false

    suspend fun createReport(
        category: Category,
        description: String,
        photoUrl: String?,
        lat: Double,
        lng: Double,
        address: String,
        severity: Severity,
        ai: AiResult?,
    ): Boolean {
        val u = auth.currentUser ?: throw IllegalStateException("আবার login করুন")
        val data = hashMapOf<String, Any?>(
            "category" to category.id,
            "description" to description,
            "photoUrl" to photoUrl,
            "location" to mapOf("latitude" to lat, "longitude" to lng, "address" to address),
            "severity" to severity.id,
            "verification" to Verification.Unverified.id,
            "status" to Status.Pending.id,
            "userId" to u.uid,
            "userEmail" to (u.email ?: ""),
            "createdAt" to FieldValue.serverTimestamp(),
            "source" to "android",
        )
        if (ai != null) data["ai"] = ai.toMap()
        return reports.add(data).commit()
    }

    suspend fun setStatus(id: String, status: Status): Boolean =
        reports.document(id).update(
            mapOf<String, Any>("status" to status.id, "updatedAt" to FieldValue.serverTimestamp())
        ).commit()

    suspend fun review(id: String, verification: Verification, note: String): Boolean =
        reports.document(id).update(
            mapOf<String, Any>(
                "verification" to verification.id,
                "reviewNote" to note,
                "reviewedBy" to (auth.currentUser?.email ?: ""),
                "reviewedAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp(),
            )
        ).commit()

    suspend fun saveAi(id: String, ai: AiResult): Boolean =
        reports.document(id).update(
            mapOf<String, Any>("ai" to ai.toMap(), "updatedAt" to FieldValue.serverTimestamp())
        ).commit()

    // ---------------- Photo (Netlify Blobs via /api/photo) ----------------

    suspend fun uploadPhoto(ctx: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        val bytes = shrinkJpeg(ctx, uri)
        val token = auth.currentUser?.getIdToken(false)?.await()?.token
            ?: throw IllegalStateException("আবার login করুন")
        val req = Request.Builder()
            .url("${AppConfig.SITE}/api/photo")
            .header("Authorization", "Bearer $token")
            .post(bytes.toRequestBody("image/jpeg".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            val body = r.body?.string().orEmpty()
            val json = runCatching { JSONObject(body) }.getOrNull()
            if (!r.isSuccessful) {
                val msg = json?.optString("error").orEmpty()
                throw IOException(msg.ifBlank { "Photo upload হয়নি (${r.code})" })
            }
            json?.optString("url")?.takeIf { it.isNotBlank() } ?: throw IOException("Photo upload হয়নি")
        }
    }

    /** Resize to max 1600px, fix EXIF rotation, JPEG 82% — same as the website's shrink(). */
    private fun shrinkJpeg(ctx: Context, uri: Uri, maxSide: Int = 1600): ByteArray {
        val cr = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("Photo পড়া যায়নি")
        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("Photo পড়া যায়নি")
        val rotation = runCatching { cr.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } }.getOrNull() ?: 0
        val scale = min(1f, maxSide.toFloat() / max(bmp.width, bmp.height))
        val out = if (scale < 1f || rotation != 0) {
            val m = Matrix()
            if (scale < 1f) m.postScale(scale, scale)
            if (rotation != 0) m.postRotate(rotation.toFloat())
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } else bmp
        val stream = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 82, stream)
        val bytes = stream.toByteArray()
        if (bytes.size > 5 * 1024 * 1024) throw IOException("Photo 5MB এর বেশি")
        return bytes
    }

    // ---------------- Gemini AI (Netlify /api/ai — API key server-e thake) ----------------

    /**
     * Asks Gemini (through the website's /api/ai function) to analyse a report.
     * Pass [localPhoto] before upload, or [photoUrl] ("/api/photo/...") for an existing report.
     * Throws on any failure — callers fall back to the on-device SmartAnalyzer.
     */
    suspend fun geminiAnalyze(
        ctx: Context,
        description: String,
        address: String,
        category: Category?,
        localPhoto: Uri? = null,
        photoUrl: String? = null,
    ): AiResult = withContext(Dispatchers.IO) {
        val token = auth.currentUser?.getIdToken(false)?.await()?.token
            ?: throw IllegalStateException("আবার login করুন")
        val body = JSONObject()
            .put("description", description)
            .put("address", address)
            .put("category", category?.id ?: "")
        if (localPhoto != null) {
            val bytes = runCatching { shrinkJpeg(ctx, localPhoto, 1024) }.getOrNull()
            if (bytes != null) body.put("image", Base64.encodeToString(bytes, Base64.NO_WRAP))
        } else if (!photoUrl.isNullOrBlank() && photoUrl.startsWith("/api/photo/")) {
            body.put("photoUrl", photoUrl)
        }
        val req = Request.Builder()
            .url("${AppConfig.SITE}/api/ai")
            .header("Authorization", "Bearer $token")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()
        aiHttp.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            val j = runCatching { JSONObject(text) }.getOrNull()
            if (!r.isSuccessful || j == null) {
                throw IOException(j?.optString("error")?.takeIf { it.isNotBlank() } ?: "Gemini পাওয়া যায়নি (${r.code})")
            }
            aiFromJson(j) ?: throw IOException("Gemini উত্তর বোঝা যায়নি")
        }
    }

    private fun aiFromJson(j: JSONObject): AiResult? {
        val c = Category.of(j.optString("category")) ?: return null
        val reasons = j.optJSONArray("spamReasons") ?: JSONArray()
        return AiResult(
            category = c,
            severity = Severity.of(j.optString("severity")) ?: Severity.Medium,
            agency = j.optString("agency"),
            agencyBn = j.optString("agencyBn"),
            summaryBn = j.optString("summaryBn"),
            confidence = j.optDouble("confidence", 0.5).coerceIn(0.0, 1.0),
            spam = j.optBoolean("spam", false),
            spamReasons = (0 until reasons.length()).map { reasons.optString(it) }.filter { it.isNotBlank() },
            model = j.optString("model").ifBlank { "gemini" },
        )
    }

    // ---------------- Reverse geocode (/api/geocode, falls back to Android Geocoder) ----------------

    suspend fun reverseGeocode(ctx: Context, lat: Double, lng: Double): String = withContext(Dispatchers.IO) {
        val remote = runCatching {
            val req = Request.Builder().url("${AppConfig.SITE}/api/geocode?lat=$lat&lng=$lng").build()
            http.newCall(req).execute().use { r ->
                if (r.isSuccessful) JSONObject(r.body?.string().orEmpty()).optString("display_name") else ""
            }
        }.getOrDefault("")
        if (remote.isNotBlank()) return@withContext remote
        runCatching {
            @Suppress("DEPRECATION")
            val list = Geocoder(ctx, Locale("bn", "BD")).getFromLocation(lat, lng, 1)
            list?.firstOrNull()?.getAddressLine(0)
        }.getOrNull().orEmpty()
    }

    // ---------------- Errors ----------------

    fun friendly(e: Throwable): String = when (e) {
        is FirebaseAuthException -> when (e.errorCode) {
            "ERROR_INVALID_CREDENTIAL", "ERROR_WRONG_PASSWORD", "ERROR_USER_NOT_FOUND",
            "ERROR_INVALID_LOGIN_CREDENTIALS" -> "Email বা password ভুল।"
            "ERROR_EMAIL_ALREADY_IN_USE" -> "এই email আগে থেকেই আছে।"
            "ERROR_INVALID_EMAIL" -> "Email সঠিক নয়।"
            "ERROR_WEAK_PASSWORD" -> "আরও শক্ত password দিন (কমপক্ষে ৬ অক্ষর)।"
            "ERROR_TOO_MANY_REQUESTS" -> "অনেকবার চেষ্টা হয়েছে — কিছুক্ষণ পরে আবার চেষ্টা করুন।"
            "ERROR_USER_DISABLED" -> "এই account বন্ধ করা আছে।"
            "ERROR_REQUIRES_RECENT_LOGIN" -> "নিরাপত্তার জন্য আবার login করে চেষ্টা করুন।"
            else -> e.localizedMessage ?: "Login failed"
        }
        is FirebaseNetworkException, is UnknownHostException, is SocketTimeoutException ->
            "Internet connection নেই — আবার চেষ্টা করুন।"
        is FirebaseFirestoreException -> when (e.code) {
            FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                "Permission নেই। Firestore rules update করা হয়েছে কিনা দেখুন (firestore.rules)।"
            FirebaseFirestoreException.Code.UNAVAILABLE -> "Server-এ পৌঁছানো যাচ্ছে না — internet check করুন।"
            else -> e.localizedMessage ?: "Database error"
        }
        else -> e.localizedMessage ?: e.toString()
    }
}
