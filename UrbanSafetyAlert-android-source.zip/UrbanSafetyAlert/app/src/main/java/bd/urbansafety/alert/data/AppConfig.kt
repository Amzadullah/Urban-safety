package bd.urbansafety.alert.data

/**
 * Same backend as the website (config.js): Firebase Auth + Firestore, and the Netlify
 * functions for photo upload (/api/photo) and reverse geocoding (/api/geocode).
 */
object AppConfig {
    const val SITE = "https://polite-centaur-aeea08.netlify.app"
    const val PRIVACY_URL = "$SITE/privacy"

    const val FIREBASE_API_KEY = "AIzaSyCehkSya_Ekx4ZUtg7pRRNCaPhFAQS2Ra8"
    const val FIREBASE_APP_ID = "1:272718839314:web:c4de9fc7731cd611f4a2cb"
    const val FIREBASE_PROJECT_ID = "urban-safety-alert-b92e2"
    const val FIREBASE_STORAGE_BUCKET = "urban-safety-alert-b92e2.firebasestorage.app"
    const val FIREBASE_SENDER_ID = "272718839314"

    const val DHAKA_LAT = 23.8103
    const val DHAKA_LNG = 90.4125
}
