package bd.urbansafety.alert.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

val Brand = Color(0xFF1D4ED8)
val Brand2 = Color(0xFF4F46E5)
val HeroGradient = Brush.linearGradient(listOf(Color(0xFF0B2A6B), Color(0xFF1D4ED8), Color(0xFF6366F1)))
val BrandGradient = Brush.linearGradient(listOf(Brand, Brand2))

private val Light = lightColorScheme(
    primary = Brand,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDBE7FF),
    onPrimaryContainer = Color(0xFF0B2A6B),
    secondary = Brand2,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFE4E4FF),
    onSecondaryContainer = Color(0xFF1E1B6B),
    background = Color(0xFFF4F6FB),
    onBackground = Color(0xFF0F172A),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFEEF2F8),
    onSurfaceVariant = Color(0xFF64748B),
    surfaceContainer = Color(0xFFF7F9FD),
    surfaceContainerLow = Color(0xFFFFFFFF),
    surfaceContainerHigh = Color(0xFFEFF3FA),
    outline = Color(0xFFCBD5E1),
    outlineVariant = Color(0xFFE2E8F0),
    error = Color(0xFFB3261E),
)

private val Dark = darkColorScheme(
    primary = Color(0xFF9DB8FF),
    onPrimary = Color(0xFF00287A),
    primaryContainer = Color(0xFF1D3B8F),
    onPrimaryContainer = Color(0xFFDBE7FF),
    secondary = Color(0xFFB4B6FF),
    background = Color(0xFF0B1220),
    onBackground = Color(0xFFE5EAF3),
    surface = Color(0xFF111A2E),
    onSurface = Color(0xFFE5EAF3),
    surfaceVariant = Color(0xFF1B2540),
    onSurfaceVariant = Color(0xFF9AA8C0),
    surfaceContainer = Color(0xFF141E34),
    surfaceContainerLow = Color(0xFF111A2E),
    surfaceContainerHigh = Color(0xFF1B2540),
    outline = Color(0xFF3A4766),
    outlineVariant = Color(0xFF26324F),
)

@Composable
fun UrbanTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) Dark else Light, content = content)
}
