@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package bd.urbansafety.alert.ui.citizen

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import bd.urbansafety.alert.data.Report
import bd.urbansafety.alert.data.Status
import bd.urbansafety.alert.data.Verification
import bd.urbansafety.alert.ui.auth.AccountMenu
import bd.urbansafety.alert.ui.auth.Session
import bd.urbansafety.alert.ui.components.EmptyState
import bd.urbansafety.alert.ui.components.MessageEffect
import bd.urbansafety.alert.ui.components.NotificationPermissionEffect
import bd.urbansafety.alert.ui.components.ReportCard
import bd.urbansafety.alert.ui.components.SeverityPill
import bd.urbansafety.alert.ui.components.ShieldLogo
import bd.urbansafety.alert.ui.components.StatusPill
import bd.urbansafety.alert.ui.components.StatusTimeline
import bd.urbansafety.alert.ui.components.VerificationPill
import bd.urbansafety.alert.ui.components.fmtDate
import bd.urbansafety.alert.ui.components.statusColors
import coil.compose.AsyncImage

@Composable
fun CitizenHome(session: Session.SignedIn, onSignOut: () -> Unit) {
    val vm: CitizenViewModel = viewModel(key = "citizen-${session.uid}-${session.n}")
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snack = remember { SnackbarHostState() }
    MessageEffect(vm.message, snack) { vm.message = null }
    NotificationPermissionEffect()
    val active = vm.reports.count { it.statusEnum != Status.Resolved }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = { ShieldLogo(Modifier.padding(start = 14.dp, end = 6.dp)) },
                title = {
                    Column {
                        Text("Urban Safety Alert", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(session.email, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                },
                actions = {
                    AccountMenu()
                },
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0, onClick = { tab = 0 },
                    icon = { Icon(Icons.Filled.AddCircle, contentDescription = null) },
                    label = { Text("New report") },
                )
                NavigationBarItem(
                    selected = tab == 1, onClick = { tab = 1 },
                    icon = {
                        BadgedBox(badge = { if (active > 0) Badge { Text("$active") } }) {
                            Icon(Icons.AutoMirrored.Filled.List, contentDescription = null)
                        }
                    },
                    label = { Text("My reports") },
                )
            }
        },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            if (tab == 0) ReportFormScreen(vm, onSubmitted = { tab = 1 }) else MyReportsScreen(vm)
        }
    }

}

@Composable
private fun CountTile(label: String, count: Int, status: Status?, modifier: Modifier) {
    val (fg, bg) = status?.let { statusColors(it) } ?: (MaterialTheme.colorScheme.onSurface to MaterialTheme.colorScheme.surface)
    Card(modifier, shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = bg)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Text("$count", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = fg)
            Text(label, style = MaterialTheme.typography.labelSmall, color = fg.copy(alpha = 0.8f), maxLines = 1)
        }
    }
}

@Composable
fun MyReportsScreen(vm: CitizenViewModel) {
    var openId by rememberSaveable { mutableStateOf<String?>(null) }
    when {
        vm.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        vm.listError != null && vm.reports.isEmpty() -> EmptyState("⚠️", "Reports load হয়নি", vm.listError ?: "")
        vm.reports.isEmpty() -> EmptyState("📭", "এখনো কোনো report নেই", "‘New report’ থেকে আপনার এলাকার সমস্যা জানান।")
        else -> LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CountTile("Total", vm.reports.size, null, Modifier.weight(1f))
                    Status.entries.forEach { s -> CountTile(s.id, vm.reports.count { it.statusEnum == s }, s, Modifier.weight(1f)) }
                }
            }
            items(vm.reports, key = { it.id }) { r -> ReportCard(r, onClick = { openId = r.id }) }
        }
    }
    val sel = vm.reports.firstOrNull { it.id == openId }
    if (sel != null) {
        ModalBottomSheet(
            onDismissRequest = { openId = null },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        ) { CitizenReportDetail(sel) }
    }
}

@Composable
private fun CitizenReportDetail(r: Report) {
    Column(
        Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(start = 20.dp, end = 20.dp, bottom = 36.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Text(r.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            StatusPill(r.statusEnum)
            r.effectiveSeverity?.let { SeverityPill(it) }
            VerificationPill(r.verificationEnum)
        }
        StatusTimeline(r.statusEnum, Modifier.padding(vertical = 4.dp))
        r.photoFullUrl?.let {
            AsyncImage(
                model = it, contentDescription = "Report photo", contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
            )
        }
        if (r.address.isNotBlank()) Text("📍 ${r.address}", style = MaterialTheme.typography.bodyMedium)
        Text(
            "Submitted ${fmtDate(r.createdAt)}" + (r.updatedAt?.let { " · Updated ${fmtDate(it)}" } ?: ""),
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        if (r.description.isNotBlank()) Text(r.description, style = MaterialTheme.typography.bodyLarge)

        if (r.verificationEnum != Verification.Unverified || r.reviewNote.isNotBlank()) {
            val rejected = r.verificationEnum == Verification.Rejected
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = if (rejected) Color(0xFFFDE2E1) else Color(0xFFE1F5EC)),
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        if (rejected) "Authority এই report টি reject করেছে" else "Authority এই report টি verify করেছে ✓",
                        fontWeight = FontWeight.SemiBold, color = if (rejected) Color(0xFF8C1D18) else Color(0xFF0F5132),
                    )
                    if (r.reviewNote.isNotBlank()) {
                        Spacer(Modifier.height(4.dp))
                        Text("Note: ${r.reviewNote}", color = if (rejected) Color(0xFF8C1D18) else Color(0xFF0F5132), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        r.ai?.let { ai ->
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text("সারসংক্ষেপ", fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
                    Spacer(Modifier.height(4.dp))
                    Text(ai.summaryBn, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        Spacer(Modifier.width(1.dp))
    }
}
