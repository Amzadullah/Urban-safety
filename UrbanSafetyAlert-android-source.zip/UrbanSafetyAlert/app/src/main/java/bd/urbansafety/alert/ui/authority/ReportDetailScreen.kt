@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package bd.urbansafety.alert.ui.authority

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import bd.urbansafety.alert.data.Report
import bd.urbansafety.alert.data.Status
import bd.urbansafety.alert.data.Verification
import bd.urbansafety.alert.ui.components.AiCard
import bd.urbansafety.alert.ui.components.SeverityPill
import bd.urbansafety.alert.ui.components.StatusPill
import bd.urbansafety.alert.ui.components.StatusTimeline
import bd.urbansafety.alert.ui.components.VerificationPill
import bd.urbansafety.alert.ui.components.fmtDate
import bd.urbansafety.alert.ui.map.SinglePinMap
import coil.compose.AsyncImage
import java.util.Locale

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            content()
        }
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(88.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun BusyIcon(active: Boolean, content: @Composable () -> Unit) {
    if (active) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else content()
}

@Composable
fun ReportDetailScreen(r: Report, vm: AuthorityViewModel, snack: SnackbarHostState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var note by rememberSaveable(r.id) { mutableStateOf(r.reviewNote) }
    var zoomPhoto by remember { mutableStateOf(false) }
    val busy = vm.busy

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
                title = { Text(r.title, fontWeight = FontWeight.Bold) },
                actions = {
                    if (r.lat != null && r.lng != null) {
                        IconButton(onClick = {
                            val uri = Uri.parse("geo:${r.lat},${r.lng}?q=${r.lat},${r.lng}(${Uri.encode(r.categoryEnum?.id ?: "Report")})")
                            try {
                                ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
                            } catch (_: ActivityNotFoundException) {
                                vm.message = "কোনো map app পাওয়া যায়নি"
                            }
                        }) { Icon(Icons.Filled.Directions, contentDescription = "Open in maps") }
                    }
                },
            )
        },
        snackbarHost = { SnackbarHost(snack) },
    ) { pad ->
        Column(
            Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                StatusPill(r.statusEnum)
                r.effectiveSeverity?.let { SeverityPill(it) }
                VerificationPill(r.verificationEnum)
            }

            r.photoFullUrl?.let { url ->
                AsyncImage(
                    model = url, contentDescription = "Report photo (tap to enlarge)", contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(230.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { zoomPhoto = true },
                )
            }

            Section("Details") {
                InfoLine("Address", r.address.ifBlank { "—" })
                InfoLine("Reported", fmtDate(r.createdAt))
                r.updatedAt?.let { InfoLine("Updated", fmtDate(it)) }
                InfoLine("Reporter", r.userEmail.ifBlank { "—" })
                if (r.lat != null && r.lng != null) InfoLine("Coordinates", String.format(Locale.US, "%.5f, %.5f", r.lat, r.lng))
                Text(
                    r.description.ifBlank { "No description" },
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (r.description.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }

            if (r.lat != null && r.lng != null) {
                SinglePinMap(r.lat, r.lng, Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(16.dp)))
            }

            val ai = r.ai
            if (ai != null) {
                AiCard(ai) {
                    OutlinedButton(onClick = { vm.rerunAi(r) }, enabled = busy == null) {
                        BusyIcon(busy == "ai") { Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp)) }
                        Spacer(Modifier.width(6.dp)); Text("Re-run AI")
                    }
                }
            } else {
                Section("AI analysis") {
                    Text("এই report এ এখনো AI analysis নেই (পুরনো web report)।", style = MaterialTheme.typography.bodyMedium)
                    Button(onClick = { vm.rerunAi(r) }, enabled = busy == null) {
                        BusyIcon(busy == "ai") { Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp)) }
                        Spacer(Modifier.width(6.dp)); Text("Run AI analysis")
                    }
                }
            }

            Section("Verification") {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    VerificationPill(r.verificationEnum)
                    if (r.reviewedBy.isNotBlank()) {
                        Spacer(Modifier.width(8.dp))
                        Text("by ${r.reviewedBy}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                OutlinedTextField(
                    value = note, onValueChange = { if (it.length <= 500) { note = it } },
                    label = { Text("Review note (citizen দেখতে পাবেন)") },
                    minLines = 2, modifier = Modifier.fillMaxWidth(),
                )
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { vm.review(r, Verification.Verified, note) },
                        enabled = busy == null,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A), contentColor = Color.White),
                        modifier = Modifier.weight(1f),
                    ) {
                        BusyIcon(busy == "review-Verified") { Icon(Icons.Filled.Verified, contentDescription = null, modifier = Modifier.size(18.dp)) }
                        Spacer(Modifier.width(6.dp)); Text("Verify")
                    }
                    OutlinedButton(
                        onClick = { vm.review(r, Verification.Rejected, note) },
                        enabled = busy == null,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFB3261E)),
                        modifier = Modifier.weight(1f),
                    ) {
                        BusyIcon(busy == "review-Rejected") { Icon(Icons.Filled.Block, contentDescription = null, modifier = Modifier.size(18.dp)) }
                        Spacer(Modifier.width(6.dp)); Text("Reject")
                    }
                }
            }

            Section("Resolution status") {
                StatusTimeline(r.statusEnum)
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    Status.entries.forEachIndexed { i, s ->
                        SegmentedButton(
                            selected = r.statusEnum == s,
                            onClick = { vm.setStatus(r, s) },
                            enabled = busy == null,
                            shape = SegmentedButtonDefaults.itemShape(index = i, count = Status.entries.size),
                        ) { Text(s.id, maxLines = 1, style = MaterialTheme.typography.labelMedium) }
                    }
                }
                if (busy == "status") Text("Updating…", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    val photo = r.photoFullUrl
    if (zoomPhoto && photo != null) {
        Dialog(onDismissRequest = { zoomPhoto = false }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(
                Modifier.fillMaxSize().background(Color.Black).clickable { zoomPhoto = false },
                contentAlignment = Alignment.Center,
            ) {
                AsyncImage(model = photo, contentDescription = "Report photo", contentScale = ContentScale.Fit, modifier = Modifier.fillMaxWidth())
            }
        }
    }
}
