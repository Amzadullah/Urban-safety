@file:OptIn(ExperimentalLayoutApi::class)

package bd.urbansafety.alert.ui.components

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import bd.urbansafety.alert.data.AiResult
import bd.urbansafety.alert.data.Report
import bd.urbansafety.alert.data.Severity
import bd.urbansafety.alert.data.Status
import bd.urbansafety.alert.data.Verification
import bd.urbansafety.alert.ui.theme.BrandGradient
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ---------------- colours ----------------

/** (foreground, background) */
fun statusColors(s: Status): Pair<Color, Color> = when (s) {
    Status.Pending -> Color(0xFF9A5B00) to Color(0xFFFFF1D6)
    Status.InProgress -> Color(0xFF1D4ED8) to Color(0xFFDBE7FF)
    Status.Resolved -> Color(0xFF16724F) to Color(0xFFE1F5EC)
}

fun statusPinColor(s: Status): Color = when (s) {
    Status.Pending -> Color(0xFFEA8A00)
    Status.InProgress -> Color(0xFF1D4ED8)
    Status.Resolved -> Color(0xFF16A34A)
}

fun severityColors(s: Severity): Pair<Color, Color> = when (s) {
    Severity.Low -> Color(0xFF3F6212) to Color(0xFFECFCCB)
    Severity.Medium -> Color(0xFF92400E) to Color(0xFFFEF3C7)
    Severity.High -> Color(0xFFC2410C) to Color(0xFFFFEDD5)
    Severity.Critical -> Color.White to Color(0xFFDC2626)
}

fun verificationColors(v: Verification): Pair<Color, Color> = when (v) {
    Verification.Verified -> Color(0xFF16724F) to Color(0xFFE1F5EC)
    Verification.Rejected -> Color(0xFFB3261E) to Color(0xFFFDE2E1)
    Verification.Unverified -> Color(0xFF475569) to Color(0xFFEEF2F7)
}

// ---------------- formatting ----------------

fun fmtDate(d: Date?): String =
    d?.let { SimpleDateFormat("d MMM yyyy, h:mm a", Locale.ENGLISH).format(it) } ?: "Just now"

// ---------------- pills ----------------

@Composable
fun Pill(text: String, fg: Color, bg: Color, modifier: Modifier = Modifier) {
    Text(
        text,
        color = fg,
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .padding(horizontal = 9.dp, vertical = 3.dp),
    )
}

@Composable
fun StatusPill(s: Status) {
    val (fg, bg) = statusColors(s); Pill(s.id, fg, bg)
}

@Composable
fun SeverityPill(s: Severity) {
    val (fg, bg) = severityColors(s); Pill(s.id, fg, bg)
}

@Composable
fun VerificationPill(v: Verification) {
    val (fg, bg) = verificationColors(v)
    Pill(if (v == Verification.Verified) "✓ Verified" else if (v == Verification.Rejected) "✕ Rejected" else "Unverified", fg, bg)
}

@Composable
fun ShieldLogo(modifier: Modifier = Modifier, size: Int = 34) {
    Box(
        modifier
            .size(size.dp)
            .clip(RoundedCornerShape((size * 0.3).dp))
            .background(BrandGradient),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.Shield, contentDescription = null, tint = Color.White, modifier = Modifier.size((size * 0.58).dp))
    }
}

// ---------------- report card ----------------

@Composable
fun ReportCard(r: Report, onClick: () -> Unit, showReporter: Boolean = false) {
    ElevatedCard(onClick = onClick, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center,
            ) { Text(r.categoryEnum?.emoji ?: "📍", fontSize = 22.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(r.categoryEnum?.id ?: r.category, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(
                    r.address.ifBlank { "No address" },
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
                if (r.description.isNotBlank()) {
                    Text(
                        r.description, style = MaterialTheme.typography.bodyMedium,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp),
                    )
                }
                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier.padding(top = 8.dp),
                ) {
                    StatusPill(r.statusEnum)
                    r.effectiveSeverity?.let { SeverityPill(it) }
                    VerificationPill(r.verificationEnum)
                    if (r.ai?.spam == true) Pill("Possible spam", Color(0xFFB3261E), Color(0xFFFDE2E1))
                }
                Text(
                    fmtDate(r.createdAt) + if (showReporter && r.userEmail.isNotBlank()) " · ${r.userEmail}" else "",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }
            r.photoFullUrl?.let {
                AsyncImage(
                    model = it, contentDescription = "Report photo", contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .padding(start = 10.dp)
                        .size(64.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                )
            }
        }
    }
}

// ---------------- AI card ----------------

@Composable
private fun KeyValue(key: String, value: @Composable () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(key, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.width(78.dp))
        Box(Modifier.weight(1f)) { value() }
    }
}

@Composable
fun AiCard(
    ai: AiResult,
    modifier: Modifier = Modifier,
    title: String = "AI analysis",
    actions: @Composable RowScope.() -> Unit = {},
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f)),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                if (ai.isGemini) Pill("Gemini", Color.White, Color(0xFF4F46E5)) else Pill("On-device", Color(0xFF475569), Color(0xFFEEF2F7))
                Spacer(Modifier.weight(1f))
                Text("${(ai.confidence * 100).roundToInt()}% confidence", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            LinearProgressIndicator(
                progress = { ai.confidence.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(50)),
            )
            KeyValue("Category") { Text("${ai.category.emoji} ${ai.category.id}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold) }
            KeyValue("Severity") { SeverityPill(ai.severity) }
            KeyValue("Agency") { Text(ai.agency, style = MaterialTheme.typography.bodyMedium) }
            Text(
                ai.summaryBn,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(12.dp),
            )
            if (ai.spam) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xFFFDE2E1))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Warning, contentDescription = null, tint = Color(0xFFB3261E), modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Possible spam: " + ai.spamReasons.joinToString(", "),
                        color = Color(0xFF8C1D18), style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            Text(
                "Suggestions support review — they don't dispatch a response automatically.",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically, content = actions)
        }
    }
}

// ---------------- status timeline ----------------

@Composable
fun StatusTimeline(current: Status, modifier: Modifier = Modifier) {
    val steps = Status.entries
    val on = MaterialTheme.colorScheme.primary
    val off = MaterialTheme.colorScheme.outlineVariant
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
        steps.forEachIndexed { i, s ->
            val done = s.ordinal <= current.ordinal
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f).height(3.dp).background(if (i == 0) Color.Transparent else if (done) on else off))
                    Box(
                        Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (done) on else MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (done) Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(16.dp))
                        else Text("${i + 1}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    val nextDone = i < steps.lastIndex && steps[i + 1].ordinal <= current.ordinal
                    Box(Modifier.weight(1f).height(3.dp).background(if (i == steps.lastIndex) Color.Transparent else if (nextDone) on else off))
                }
                Spacer(Modifier.height(6.dp))
                Text(s.id, style = MaterialTheme.typography.labelMedium, fontWeight = if (s == current) FontWeight.Bold else FontWeight.Normal, textAlign = TextAlign.Center)
                Text(s.bn, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
            }
        }
    }
}

// ---------------- misc ----------------

@Composable
fun EmptyState(emoji: String, title: String, subtitle: String, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text(emoji, fontSize = 48.sp)
        Spacer(Modifier.height(12.dp))
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
    }
}

/** Shows a one-off message in the snackbar, then clears it. */
@Composable
fun MessageEffect(message: String?, snack: SnackbarHostState, onShown: () -> Unit) {
    val scope = rememberCoroutineScope()
    LaunchedEffect(message) {
        val m = message ?: return@LaunchedEffect
        scope.launch { snack.showSnackbar(m) }
        onShown()
    }
}

@Composable
fun NotificationPermissionEffect() {
    if (Build.VERSION.SDK_INT < 33) return
    val ctx = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }
}
