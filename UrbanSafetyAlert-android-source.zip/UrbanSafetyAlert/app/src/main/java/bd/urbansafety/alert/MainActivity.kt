package bd.urbansafety.alert

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import bd.urbansafety.alert.data.Role
import bd.urbansafety.alert.ui.auth.AuthScreen
import bd.urbansafety.alert.ui.auth.Session
import bd.urbansafety.alert.ui.auth.SessionViewModel
import bd.urbansafety.alert.ui.auth.SplashScreen
import bd.urbansafety.alert.ui.authority.AuthorityHome
import bd.urbansafety.alert.ui.citizen.CitizenHome
import bd.urbansafety.alert.ui.theme.UrbanTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { UrbanTheme { App() } }
    }
}

@Composable
fun App(vm: SessionViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    when (val s = state) {
        Session.Loading -> SplashScreen()
        Session.SignedOut -> AuthScreen(vm)
        is Session.SignedIn ->
            if (s.role == Role.Authority) AuthorityHome(s, onSignOut = vm::signOut)
            else CitizenHome(s, onSignOut = vm::signOut)
    }
}
