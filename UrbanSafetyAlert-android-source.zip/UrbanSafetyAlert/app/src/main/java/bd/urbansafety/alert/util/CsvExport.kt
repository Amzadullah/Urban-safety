package bd.urbansafety.alert.util

import android.content.ClipData
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import bd.urbansafety.alert.data.Report
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExport {
    private val HEADER = listOf(
        "id", "created_at", "category", "severity", "status", "verification", "address", "latitude", "longitude",
        "description", "reporter_email", "ai_category", "ai_severity", "ai_agency", "ai_confidence", "ai_spam",
        "ai_summary_bn", "review_note", "reviewed_by", "photo_url",
    )

    fun build(reports: List<Report>): String {
        val iso = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US)
        val sb = StringBuilder()
        sb.append(HEADER.joinToString(",")).append("\r\n")
        reports.forEach { r ->
            val row = listOf(
                r.id, r.createdAt?.let { iso.format(it) }, r.category, r.effectiveSeverity?.id, r.status,
                r.verification, r.address, r.lat, r.lng, r.description, r.userEmail, r.ai?.category?.id,
                r.ai?.severity?.id, r.ai?.agency, r.ai?.confidence?.let { String.format(Locale.US, "%.2f", it) },
                r.ai?.spam, r.ai?.summaryBn, r.reviewNote, r.reviewedBy, r.photoFullUrl,
            )
            sb.append(row.joinToString(",") { esc(it) }).append("\r\n")
        }
        return sb.toString()
    }

    private fun esc(v: Any?): String {
        var s = v?.toString() ?: ""
        // Prevent spreadsheet formula injection
        if (s.isNotEmpty() && s[0] in "=+-@" && v !is Number) s = "'$s"
        return if (s.any { it == ',' || it == '"' || it == '\n' || it == '\r' }) "\"" + s.replace("\"", "\"\"") + "\"" else s
    }

    fun share(ctx: Context, reports: List<Report>) {
        val dir = File(ctx.cacheDir, "shared").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
        val f = File(dir, "urban-safety-reports-$stamp.csv")
        // BOM so Excel shows Bengali text correctly
        f.writeText("﻿" + build(reports), Charsets.UTF_8)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "Urban Safety Alert – ${reports.size} reports")
            clipData = ClipData.newRawUri(f.name, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(
            Intent.createChooser(send, "Export ${reports.size} reports (CSV)")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
