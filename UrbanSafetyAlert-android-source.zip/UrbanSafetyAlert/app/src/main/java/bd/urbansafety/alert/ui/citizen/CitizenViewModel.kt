package bd.urbansafety.alert.ui.citizen

import android.annotation.SuppressLint
import android.app.Application
import android.net.Uri
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import bd.urbansafety.alert.ai.SmartAnalyzer
import bd.urbansafety.alert.data.AiResult
import bd.urbansafety.alert.data.AppConfig
import bd.urbansafety.alert.data.Category
import bd.urbansafety.alert.data.Report
import bd.urbansafety.alert.data.Repo
import bd.urbansafety.alert.data.Severity
import bd.urbansafety.alert.data.Status
import bd.urbansafety.alert.data.Verification
import bd.urbansafety.alert.util.Notifier
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withTimeoutOrNull

class CitizenViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()

    // ---------- my reports (live) ----------
    var reports by mutableStateOf<List<Report>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var listError by mutableStateOf<String?>(null)
        private set
    var message by mutableStateOf<String?>(null)

    private var known: Map<String, String>? = null
    private var listenJob: Job? = null
    private val authListener = FirebaseAuth.AuthStateListener { if (it.currentUser == null) listenJob?.cancel() }

    // ---------- new report form ----------
    var category by mutableStateOf(Category.Streetlight)
    var description by mutableStateOf("")
    var photoUri by mutableStateOf<Uri?>(null)
    var address by mutableStateOf("")
    var severity by mutableStateOf<Severity?>(null)

    var lat by mutableStateOf(AppConfig.DHAKA_LAT)
        private set
    var lng by mutableStateOf(AppConfig.DHAKA_LNG)
        private set
    var locationSet by mutableStateOf(false)
        private set
    var addressLoading by mutableStateOf(false)
        private set
    var locating by mutableStateOf(false)
        private set
    var recenter by mutableIntStateOf(0)
        private set
    var submitting by mutableStateOf(false)
        private set
    var submitStage by mutableStateOf("")
        private set
    var submitError by mutableStateOf<String?>(null)

    /** Instant on-device preview, recomputed as the citizen types. */
    val localAi: AiResult? by derivedStateOf {
        if (description.trim().length < 6) null
        else SmartAnalyzer.analyze(description, address, photoUri != null, category)
    }

    // Gemini result is valid only for the exact description/category/photo it was made for
    private var geminiResult by mutableStateOf<AiResult?>(null)
    private var geminiKey by mutableStateOf("")
    var geminiBusy by mutableStateOf(false)
        private set
    private fun currentKey() = "${description.trim()}|${category.id}|$photoUri"

    /** Gemini result if it matches the current form, otherwise the on-device preview. */
    val aiPreview: AiResult? by derivedStateOf {
        val g = geminiResult
        if (g != null && geminiKey == currentKey()) g else localAi
    }

    fun analyzeWithGemini() {
        if (geminiBusy) return
        if (description.trim().length < 6 && photoUri == null) {
            message = "আগে সমস্যার বিবরণ লিখুন বা photo দিন"; return
        }
        val key = currentKey()
        viewModelScope.launch {
            geminiBusy = true
            try {
                geminiResult = Repo.geminiAnalyze(ctx, description.trim(), address, category, localPhoto = photoUri)
                geminiKey = key
                message = "Gemini analysis ready ✓"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "Gemini এখন পাওয়া যাচ্ছে না (${Repo.friendly(e)}) — on-device AI দেখানো হচ্ছে"
            } finally {
                geminiBusy = false
            }
        }
    }

    private var geoJob: Job? = null

    init {
        Repo.auth.addAuthStateListener(authListener)
        val uid = Repo.auth.currentUser?.uid
        if (uid != null) {
            listenJob = viewModelScope.launch {
                Repo.myReports(uid)
                    .catch { e ->
                        listError = Repo.friendly(e); loading = false
                    }
                    .collect { list ->
                        notifyChanges(list)
                        reports = list; loading = false; listError = null
                    }
            }
        } else loading = false
    }

    override fun onCleared() {
        Repo.auth.removeAuthStateListener(authListener)
    }

    private fun notifyChanges(list: List<Report>) {
        val prev = known
        if (prev != null) {
            list.forEach { r ->
                val old = prev[r.id] ?: return@forEach
                val now = "${r.status}|${r.verification}"
                if (old == now) return@forEach
                val (oldStatus, oldVer) = old.split("|").let { it[0] to it.getOrElse(1) { "" } }
                val text = when {
                    oldStatus != r.status -> when (r.statusEnum) {
                        Status.InProgress -> "কাজ শুরু হয়েছে — ${r.address.ifBlank { r.title }}"
                        Status.Resolved -> "সমাধান হয়েছে ✓ — ${r.address.ifBlank { r.title }}"
                        Status.Pending -> "আবার Pending করা হয়েছে"
                    }
                    oldVer != r.verification -> when (r.verificationEnum) {
                        Verification.Verified -> "Authority report টি verify করেছে ✓"
                        Verification.Rejected -> "Report টি reject হয়েছে" + if (r.reviewNote.isNotBlank()) ": ${r.reviewNote}" else ""
                        Verification.Unverified -> "Verification reset করা হয়েছে"
                    }
                    else -> return@forEach
                }
                Notifier.show(ctx, r.id.hashCode(), "${r.title} · ${r.status}", text)
            }
        }
        known = list.associate { it.id to "${it.status}|${it.verification}" }
    }

    // ---------- form actions ----------

    fun setLocation(la: Double, ln: Double) {
        lat = la; lng = ln; locationSet = true
        geoJob?.cancel()
        geoJob = viewModelScope.launch {
            addressLoading = true
            try {
                val a = Repo.reverseGeocode(ctx, la, ln)
                if (a.isNotBlank()) address = a
            } finally {
                addressLoading = false
            }
        }
    }

    @SuppressLint("MissingPermission") // caller checks permission first
    fun locateMe() {
        if (locating) return
        viewModelScope.launch {
            locating = true
            try {
                val client = LocationServices.getFusedLocationProviderClient(ctx)
                val loc = client.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, CancellationTokenSource().token).await()
                    ?: client.lastLocation.await()
                if (loc == null) {
                    message = "Location পাওয়া যায়নি — GPS চালু করে আবার চেষ্টা করুন।"
                } else {
                    setLocation(loc.latitude, loc.longitude)
                    recenter++
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = "Location পাওয়া যায়নি: ${Repo.friendly(e)}"
            } finally {
                locating = false
            }
        }
    }

    fun applyAi() {
        val ai = aiPreview ?: return
        val key = currentKey()
        category = ai.category
        severity = ai.severity
        // keep a Gemini result valid after its own category is applied
        if (ai.isGemini && geminiKey == key) geminiKey = currentKey()
        message = "AI suggestion applied: ${ai.category.id} · ${ai.severity.id}"
    }

    /** Calls [onSpam] instead of submitting if the analyzer flags spam and [force] is false. */
    fun submit(force: Boolean, onSpam: () -> Unit, onDone: () -> Unit) {
        if (submitting) return
        submitError = null
        val desc = description.trim()
        if (desc.length < 5 && photoUri == null) {
            submitError = "সমস্যার বিবরণ লিখুন অথবা একটি photo দিন।"
            return
        }
        if (desc.length > 1000) {
            submitError = "বিবরণ ১০০০ অক্ষরের মধ্যে রাখুন।"
            return
        }
        val preview = aiPreview ?: SmartAnalyzer.analyze(desc, address, photoUri != null, category)
        if (preview.spam && !force) {
            onSpam(); return
        }
        val key = currentKey()
        viewModelScope.launch {
            submitting = true
            try {
                var url: String? = null
                val photo = photoUri
                if (photo != null) {
                    submitStage = "Photo uploading…"
                    url = Repo.uploadPhoto(ctx, photo)
                }
                // Gemini (with photo) if available; fall back to the on-device analyzer
                val ai: AiResult = geminiResult?.takeIf { geminiKey == key } ?: run {
                    submitStage = "AI analysing…"
                    withTimeoutOrNull(20_000L) {
                        runCatching { Repo.geminiAnalyze(ctx, desc, address, category, photoUrl = url) }.getOrNull()
                    }
                } ?: SmartAnalyzer.analyze(desc, address, photo != null, category)
                submitStage = "Submitting…"
                val synced = Repo.createReport(category, desc, url, lat, lng, address.trim(), severity ?: ai.severity, ai)
                message = if (synced) "Report submitted ✓" else "Offline — report saved, internet এলে পাঠানো হবে"
                description = ""; photoUri = null; severity = null; geminiResult = null
                onDone()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                submitError = Repo.friendly(e)
            } finally {
                submitting = false
            }
        }
    }
}
