package bd.urbansafety.alert.data

import com.google.firebase.firestore.DocumentSnapshot
import java.util.Date

enum class Role(val id: String) { Citizen("citizen"), Authority("authority") }

/** `id` is the exact string stored in Firestore (shared with the website). */
enum class Category(val id: String, val emoji: String, val bn: String) {
    Streetlight("Streetlight", "💡", "স্ট্রিটলাইট"),
    Crime("Crime", "🚨", "অপরাধ"),
    Accident("Accident", "🚗", "দুর্ঘটনা"),
    Hazard("Hazard", "⚠️", "ঝুঁকিপূর্ণ বিপদ"),
    Waterlogging("Waterlogging", "🌊", "জলাবদ্ধতা"),
    RoadDamage("Road Damage", "🛣️", "রাস্তা ক্ষতিগ্রস্ত"),
    Footpath("Footpath", "🚶", "ফুটপাত"),
    Garbage("Garbage", "🗑️", "ময়লা-আবর্জনা");

    companion object {
        fun of(id: String?): Category? = entries.firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) }
    }
}

enum class Severity(val id: String, val bn: String) {
    Low("Low", "কম"),
    Medium("Medium", "মাঝারি"),
    High("High", "বেশি"),
    Critical("Critical", "সংকটপূর্ণ");

    companion object {
        fun of(id: String?): Severity? = entries.firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) }
    }
}

enum class Status(val id: String, val bn: String) {
    Pending("Pending", "অপেক্ষমাণ"),
    InProgress("In Progress", "কাজ চলছে"),
    Resolved("Resolved", "সমাধান হয়েছে");

    companion object {
        fun of(id: String?): Status = entries.firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) } ?: Pending
    }
}

enum class Verification(val id: String) {
    Unverified("Unverified"), Verified("Verified"), Rejected("Rejected");

    companion object {
        fun of(id: String?): Verification = entries.firstOrNull { it.id.equals(id?.trim(), ignoreCase = true) } ?: Unverified
    }
}

data class AiResult(
    val category: Category,
    val severity: Severity,
    val agency: String,
    val agencyBn: String,
    val summaryBn: String,
    val confidence: Double,
    val spam: Boolean,
    val spamReasons: List<String>,
    val model: String = MODEL,
) {
    val isGemini: Boolean get() = model.startsWith("gemini")

    fun toMap(): Map<String, Any> = mapOf(
        "category" to category.id,
        "severity" to severity.id,
        "agency" to agency,
        "agencyBn" to agencyBn,
        "summaryBn" to summaryBn,
        "confidence" to confidence,
        "spam" to spam,
        "spamReasons" to spamReasons,
        "model" to model,
    )

    companion object {
        const val MODEL = "on-device-v1"

        fun from(m: Map<*, *>?): AiResult? {
            if (m == null) return null
            val c = Category.of(m["category"] as? String) ?: return null
            return AiResult(
                category = c,
                severity = Severity.of(m["severity"] as? String) ?: Severity.Medium,
                agency = m["agency"] as? String ?: "",
                agencyBn = m["agencyBn"] as? String ?: "",
                summaryBn = m["summaryBn"] as? String ?: "",
                confidence = (m["confidence"] as? Number)?.toDouble() ?: 0.0,
                spam = m["spam"] as? Boolean ?: false,
                spamReasons = (m["spamReasons"] as? List<*>)?.mapNotNull { it as? String } ?: emptyList(),
                model = m["model"] as? String ?: MODEL,
            )
        }
    }
}

data class Report(
    val id: String,
    val category: String,
    val description: String,
    val photoUrl: String?,
    val lat: Double?,
    val lng: Double?,
    val address: String,
    val status: String,
    val severity: String?,
    val verification: String,
    val reviewNote: String,
    val reviewedBy: String,
    val userId: String,
    val userEmail: String,
    val createdAt: Date?,
    val updatedAt: Date?,
    val ai: AiResult?,
) {
    val categoryEnum: Category? get() = Category.of(category)
    val statusEnum: Status get() = Status.of(status)
    val verificationEnum: Verification get() = Verification.of(verification)

    /** Severity chosen by the citizen, otherwise the AI suggestion. */
    val effectiveSeverity: Severity? get() = Severity.of(severity) ?: ai?.severity

    val title: String get() = categoryEnum?.let { "${it.emoji} ${it.id}" } ?: category

    /** Website stores photos as "/api/photo/..." relative to the Netlify site. */
    val photoFullUrl: String?
        get() = photoUrl?.takeIf { it.isNotBlank() }?.let { if (it.startsWith("/")) AppConfig.SITE + it else it }

    companion object {
        fun from(d: DocumentSnapshot): Report? = runCatching {
            val est = DocumentSnapshot.ServerTimestampBehavior.ESTIMATE
            Report(
                id = d.id,
                category = d.getString("category") ?: "Other",
                description = d.getString("description") ?: "",
                photoUrl = d.getString("photoUrl"),
                lat = (d.get("location.latitude") as? Number)?.toDouble(),
                lng = (d.get("location.longitude") as? Number)?.toDouble(),
                address = d.get("location.address") as? String ?: "",
                status = d.getString("status") ?: Status.Pending.id,
                severity = d.get("severity") as? String,
                verification = d.get("verification") as? String ?: Verification.Unverified.id,
                reviewNote = d.get("reviewNote") as? String ?: "",
                reviewedBy = d.get("reviewedBy") as? String ?: "",
                userId = d.getString("userId") ?: "",
                userEmail = d.get("userEmail") as? String ?: "",
                createdAt = d.getTimestamp("createdAt", est)?.toDate(),
                updatedAt = d.getTimestamp("updatedAt", est)?.toDate(),
                ai = AiResult.from(d.get("ai") as? Map<*, *>),
            )
        }.getOrNull()
    }
}
