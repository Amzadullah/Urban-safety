package bd.urbansafety.alert.ui.auth

import android.util.Patterns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import bd.urbansafety.alert.data.Repo
import bd.urbansafety.alert.data.Role
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface Session {
    data object Loading : Session
    data object SignedOut : Session

    /** [n] changes on every sign-in so per-session ViewModels start fresh. */
    data class SignedIn(val uid: String, val email: String, val role: Role, val n: Int) : Session
}

class SessionViewModel : ViewModel() {
    private val _state = MutableStateFlow<Session>(Session.Loading)
    val state: StateFlow<Session> = _state.asStateFlow()

    var busy by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)
    var info by mutableStateOf<String?>(null)

    @Volatile
    private var signingUp = false
    private var counter = 0

    private val listener = FirebaseAuth.AuthStateListener { a ->
        if (signingUp) return@AuthStateListener
        val u = a.currentUser
        if (u == null) {
            _state.value = Session.SignedOut
        } else {
            val current = _state.value
            if (current is Session.SignedIn && current.uid == u.uid) return@AuthStateListener
            viewModelScope.launch {
                val role = runCatching { Repo.roleOf(u.uid) }.getOrDefault(Role.Citizen)
                _state.value = Session.SignedIn(u.uid, u.email ?: "", role, ++counter)
                busy = false
            }
        }
    }

    init {
        Repo.auth.addAuthStateListener(listener)
    }

    override fun onCleared() {
        Repo.auth.removeAuthStateListener(listener)
    }

    private fun validate(email: String, pw: String?): Boolean {
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() || (pw != null && pw.length < 6)) {
            error = if (pw == null) "সঠিক email দিন।" else "সঠিক email ও কমপক্ষে ৬ অক্ষরের password দিন।"
            return false
        }
        return true
    }

    fun submit(signUp: Boolean, emailRaw: String, pw: String, role: Role) {
        if (busy) return
        val email = emailRaw.trim()
        error = null; info = null
        if (!validate(email, pw)) return
        viewModelScope.launch {
            busy = true
            try {
                if (signUp) {
                    signingUp = true
                    val uid = Repo.signUp(email, pw, role)
                    _state.value = Session.SignedIn(uid, email, role, ++counter)
                    busy = false
                } else {
                    Repo.signIn(email, pw) // auth listener resolves the role and switches screens
                }
            } catch (e: Exception) {
                if (signUp && Repo.auth.currentUser != null) Repo.signOut()
                error = Repo.friendly(e)
                busy = false
            } finally {
                signingUp = false
            }
        }
    }

    fun resetPassword(emailRaw: String) {
        val email = emailRaw.trim()
        error = null; info = null
        if (!validate(email, null)) return
        viewModelScope.launch {
            busy = true
            try {
                Repo.sendPasswordReset(email)
                info = "Password reset link পাঠানো হয়েছে — $email এর inbox দেখুন।"
            } catch (e: Exception) {
                error = Repo.friendly(e)
            } finally {
                busy = false
            }
        }
    }

    fun signOut() {
        Repo.signOut()
    }

    var deleting by mutableStateOf(false)
        private set
    var deleteError by mutableStateOf<String?>(null)

    fun deleteAccount(password: String) {
        if (deleting) return
        if (password.isBlank()) {
            deleteError = "Password দিন"; return
        }
        viewModelScope.launch {
            deleting = true; deleteError = null
            try {
                Repo.deleteAccount(password)
                info = "আপনার account ও সব report মুছে ফেলা হয়েছে।"
            } catch (e: Exception) {
                deleteError = Repo.friendly(e)
            } finally {
                deleting = false
            }
        }
    }
}
