package bd.urbansafety.alert.ui.authority

import android.app.Application
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import bd.urbansafety.alert.ai.SmartAnalyzer
import bd.urbansafety.alert.data.Category
import bd.urbansafety.alert.data.Report
import bd.urbansafety.alert.data.Repo
import bd.urbansafety.alert.data.Severity
import bd.urbansafety.alert.data.Status
import bd.urbansafety.alert.data.Verification
import bd.urbansafety.alert.util.Notifier
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

data class DayCount(val label: String, val count: Int)

data class Stats(
    val total: Int,
    val pending: Int,
    val inProgress: Int,
    val resolved: Int,
    val critical: Int,
    val verified: Int,
    val unverified: Int,
    val week: List<DayCount>,
    val byCategory: List<Pair<Category, Int>>,
)

class AuthorityViewModel(app: Application) : AndroidViewModel(app) {
    private val ctx get() = getApplication<Application>()

    var all by mutableStateOf<List<Report>>(emptyList())
        private set
    var loading by mutableStateOf(true)
        private set
    var loadError by mutableStateOf<String?>(null)
        private set
    var message by mutableStateOf<String?>(null)
    var busy by mutableStateOf<String?>(null)
        private set
    var selectedId by mutableStateOf<String?>(null)

    // ---------- filters ----------
    var query by mutableStateOf("")
    var fCategory by mutableStateOf<Category?>(null)
    var fStatus by mutableStateOf<Status?>(null)
    var fSeverity by mutableStateOf<Severity?>(null)
    var fVerification by mutableStateOf<Verification?>(null)

    val anyFilter: Boolean by derivedStateOf {
        query.isNotBlank() || fCategory != null || fStatus != null || fSeverity != null || fVerification != null
    }

    fun clearFilters() {
        query = ""; fCategory = null; fStatus = null; fSeverity = null; fVerification = null
    }

    val filtered: List<Report> by derivedStateOf {
        val q = query.trim().lowercase(Locale.ROOT)
        all.filter { r ->
            (fCategory == null || r.categoryEnum == fCategory) &&
                (fStatus == null || r.statusEnum == fStatus) &&
                (fSeverity == null || r.effectiveSeverity == fSeverity) &&
                (fVerification == null || r.verificationEnum == fVerification) &&
                (q.isEmpty() || "${r.address} ${r.description} ${r.category} ${r.userEmail}".lowercase(Locale.ROOT).contains(q))
        }
    }

    val selected: Report? by derivedStateOf { selectedId?.let { id -> all.firstOrNull { it.id == id } } }

    val stats: Stats by derivedStateOf { computeStats(all) }

    /** Critical/high, unresolved, newest first — shown on the dashboard. */
    val attention: List<Report> by derivedStateOf {
        all.filter {
            it.statusEnum != Status.Resolved && it.verificationEnum != Verification.Rejected &&
                (it.effectiveSeverity == Severity.Critical || it.effectiveSeverity == Severity.High)
        }.take(6)
    }

    private var knownIds: Set<String>? = null
    private var listenJob: Job? = null
    private val authListener = FirebaseAuth.AuthStateListener { if (it.currentUser == null) listenJob?.cancel() }

    init {
        Repo.auth.addAuthStateListener(authListener)
        listenJob = viewModelScope.launch {
            Repo.allReports()
                .catch { e -> loadError = Repo.friendly(e); loading = false }
                .collect { list ->
                    notifyNew(list)
                    all = list; loading = false; loadError = null
                }
        }
    }

    override fun onCleared() {
        Repo.auth.removeAuthStateListener(authListener)
    }

    private fun notifyNew(list: List<Report>) {
        val prev = knownIds
        if (prev != null) {
            val recent = System.currentTimeMillis() - 15 * 60_000L
            val fresh = list.filter { it.id !in prev && (it.createdAt?.time ?: Long.MAX_VALUE) > recent }
            fresh.take(3).forEach { r ->
                val sev = r.effectiveSeverity?.let { " · ${it.id}" } ?: ""
                Notifier.show(ctx, r.id.hashCode(), "New report: ${r.title}$sev", r.address.ifBlank { r.description.take(80) })
            }
            if (fresh.size > 3) Notifier.show(ctx, 4242, "${fresh.size} new reports", "Dashboard খুলে দেখুন")
        }
        knownIds = list.map { it.id }.toSet()
    }

    private fun computeStats(list: List<Report>): Stats {
        val dayFmt = SimpleDateFormat("EEE", Locale.ENGLISH)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            add(Calendar.DAY_OF_YEAR, -6)
        }
        val week = (0 until 7).map {
            val start = cal.timeInMillis
            val label = if (it == 6) "Today" else dayFmt.format(cal.time)
            cal.add(Calendar.DAY_OF_YEAR, 1)
            val end = cal.timeInMillis
            DayCount(label, list.count { r -> val t = r.createdAt?.time ?: return@count false; t in start until end })
        }
        return Stats(
            total = list.size,
            pending = list.count { it.statusEnum == Status.Pending },
            inProgress = list.count { it.statusEnum == Status.InProgress },
            resolved = list.count { it.statusEnum == Status.Resolved },
            critical = list.count { it.effectiveSeverity == Severity.Critical },
            verified = list.count { it.verificationEnum == Verification.Verified },
            unverified = list.count { it.verificationEnum == Verification.Unverified },
            week = week,
            byCategory = Category.entries.map { c -> c to list.count { it.categoryEnum == c } }
                .filter { it.second > 0 }.sortedByDescending { it.second },
        )
    }

    // ---------- actions ----------

    private fun act(name: String, block: suspend () -> Unit) {
        if (busy != null) return
        viewModelScope.launch {
            busy = name
            try {
                block()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                message = Repo.friendly(e)
            } finally {
                busy = null
            }
        }
    }

    private fun done(synced: Boolean, ok: String) {
        message = if (synced) ok else "Offline — change saved, internet এলে sync হবে"
    }

    fun setStatus(r: Report, s: Status) = act("status") {
        if (r.statusEnum != s) done(Repo.setStatus(r.id, s), "Status → ${s.id} ✓")
    }

    fun review(r: Report, v: Verification, note: String) = act("review-${v.id}") {
        done(Repo.review(r.id, v, note.trim()), if (v == Verification.Verified) "Report verified ✓" else "Report rejected")
    }

    /** Gemini (reads the uploaded photo on the server); falls back to the on-device analyzer. */
    fun rerunAi(r: Report) = act("ai") {
        val gemini = try {
            Repo.geminiAnalyze(ctx, r.description, r.address, r.categoryEnum, photoUrl = r.photoUrl)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
        val ai = gemini ?: SmartAnalyzer.analyze(r.description, r.address, r.photoFullUrl != null, r.categoryEnum)
        done(Repo.saveAi(r.id, ai), if (gemini != null) "Gemini analysis updated ✓" else "Gemini পাওয়া যায়নি — on-device AI দিয়ে updated")
    }
}
