package bd.urbansafety.alert.ui.auth

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Policy
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import bd.urbansafety.alert.data.AppConfig

/** Top-bar ⋮ menu: privacy policy, delete account (Play Store requirement), sign out. */
@Composable
fun AccountMenu(session: SessionViewModel = viewModel()) {
    val ctx = LocalContext.current
    var open by remember { mutableStateOf(false) }
    var confirmOut by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var password by remember { mutableStateOf("") }

    Box {
        IconButton(onClick = { open = true }) { Icon(Icons.Filled.MoreVert, contentDescription = "Account menu") }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(
                text = { Text("Privacy policy") },
                leadingIcon = { Icon(Icons.Filled.Policy, contentDescription = null) },
                onClick = {
                    open = false
                    try {
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AppConfig.PRIVACY_URL)))
                    } catch (_: ActivityNotFoundException) {
                    }
                },
            )
            DropdownMenuItem(
                text = { Text("Delete account") },
                leadingIcon = { Icon(Icons.Filled.DeleteForever, contentDescription = null, tint = Color(0xFFB3261E)) },
                onClick = { open = false; password = ""; session.deleteError = null; deleteDialog = true },
            )
            DropdownMenuItem(
                text = { Text("Sign out") },
                leadingIcon = { Icon(Icons.AutoMirrored.Filled.Logout, contentDescription = null) },
                onClick = { open = false; confirmOut = true },
            )
        }
    }

    if (confirmOut) {
        AlertDialog(
            onDismissRequest = { confirmOut = false },
            title = { Text("Sign out?") },
            confirmButton = { TextButton(onClick = { confirmOut = false; session.signOut() }) { Text("Sign out") } },
            dismissButton = { TextButton(onClick = { confirmOut = false }) { Text("Cancel") } },
        )
    }

    if (deleteDialog) {
        AlertDialog(
            onDismissRequest = { if (!session.deleting) deleteDialog = false },
            title = { Text("Account মুছে ফেলবেন?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("আপনার account, আপনার সব report ও photo স্থায়ীভাবে মুছে যাবে। এটা আর ফেরত আনা যাবে না। নিশ্চিত করতে password দিন।")
                    OutlinedTextField(
                        value = password, onValueChange = { password = it },
                        label = { Text("Password") }, singleLine = true,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                        modifier = Modifier.fillMaxWidth(),
                    )
                    session.deleteError?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                }
            },
            confirmButton = {
                TextButton(onClick = { session.deleteAccount(password) }, enabled = !session.deleting) {
                    if (session.deleting) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                    else Text("Delete permanently", color = Color(0xFFB3261E))
                }
            },
            dismissButton = { TextButton(onClick = { deleteDialog = false }, enabled = !session.deleting) { Text("Cancel") } },
        )
    }
}
