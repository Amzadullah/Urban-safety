package bd.urbansafety.alert.ai

import bd.urbansafety.alert.data.AiResult
import bd.urbansafety.alert.data.Category
import bd.urbansafety.alert.data.Severity
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max
import kotlin.math.min

/**
 * On-device report analysis (works offline, no API key): suggests category, severity,
 * responsible agency, a Bengali summary, a confidence score and a spam flag.
 * Understands English, Bengali and common Banglish words.
 * Suggestions support review — they never dispatch anything automatically.
 */
object SmartAnalyzer {

    private val KEYWORDS: Map<Category, List<String>> = mapOf(
        Category.Streetlight to listOf(
            "streetlight", "street light", "street lamp", "lamp post", "lamppost", "light", "lamp", "bulb",
            "dark", "andhar", "andhokar", "batti", "বাতি", "লাইট", "ল্যাম্প", "অন্ধকার", "আলো নেই", "খুঁটি",
        ),
        Category.Crime to listOf(
            "theft", "thief", "stolen", "steal", "robbery", "robbed", "mugging", "mugged", "snatch", "chintai",
            "harass", "eve teas", "drug", "yaba", "fight", "knife", "gun", "threat", "kidnap", "extortion",
            "crime", "gang", "ছিনতাই", "চুরি", "চোর", "ডাকাত", "হয়রানি", "ইভটিজিং", "মাদক", "ইয়াবা",
            "মারামারি", "ছুরি", "অস্ত্র", "হুমকি", "অপহরণ", "চাঁদাবাজি", "অপরাধ", "কিশোর গ্যাং",
        ),
        Category.Accident to listOf(
            "accident", "crash", "collision", "collided", "hit by", "run over", "overturn", "bike", "motorcycle",
            "bus", "truck", "rickshaw", "cng", "injured", "durghotona", "দুর্ঘটনা", "ধাক্কা", "সংঘর্ষ",
            "চাপা", "উল্টে", "আহত", "বাস", "ট্রাক", "মোটরসাইকেল", "রিকশা",
        ),
        Category.Hazard to listOf(
            "fire", "smoke", "gas", "leak", "live wire", "loose wire", "wire", "electric", "shock", "short circuit",
            "transformer", "tree fell", "fallen tree", "collapse", "crack in building", "manhole", "hazard",
            "danger", "explosion", "আগুন", "ধোঁয়া", "গ্যাস", "লিক", "তার", "বিদ্যুৎস্পৃষ্ট", "ট্রান্সফরমার",
            "গাছ", "ধস", "ভবন", "ম্যানহোল", "বিপদ", "বিস্ফোরণ", "ঝুঁকি",
        ),
        Category.Waterlogging to listOf(
            "waterlog", "water logging", "flood", "drain", "drainage", "sewer", "clogged", "rain water",
            "knee deep", "pani", "jolaboddho", "জলাবদ্ধ", "পানি জমে", "পানি", "বন্যা", "ড্রেন", "নর্দমা",
            "বৃষ্টি", "হাঁটু পানি", "স্যুয়ারেজ",
        ),
        Category.RoadDamage to listOf(
            "pothole", "road damage", "damaged road", "broken road", "road", "crack", "asphalt", "carpeting",
            "speed breaker", "bridge", "culvert", "rasta", "রাস্তা", "গর্ত", "খানাখন্দ", "ফাটল", "ভাঙা রাস্তা",
            "সড়ক", "কার্পেটিং", "ব্রিজ", "কালভার্ট",
        ),
        Category.Footpath to listOf(
            "footpath", "sidewalk", "pavement", "walkway", "pedestrian", "hawker", "encroach", "slab",
            "footover", "foot over bridge", "zebra", "ফুটপাত", "হকার", "দখল", "স্ল্যাব", "পথচারী",
            "ফুটওভার", "জেব্রা",
        ),
        Category.Garbage to listOf(
            "garbage", "trash", "waste", "rubbish", "dump", "litter", "dustbin", "smell", "stink", "plastic",
            "moyla", "ময়লা", "আবর্জনা", "বর্জ্য", "ডাস্টবিন", "দুর্গন্ধ", "পলিথিন", "ময়লার স্তূপ",
        ),
    )

    private val CRITICAL = listOf(
        "fire", "burning", "dead", "died", "death", "killed", "blood", "bleeding", "explosion", "collapse",
        "electrocut", "live wire", "trapped", "gun", "knife", "kidnap", "unconscious", "dying",
        "আগুন", "মারা", "মৃত", "নিহত", "রক্ত", "বিস্ফোরণ", "ধসে", "বিদ্যুৎস্পৃষ্ট", "খোলা তার", "আটকা",
        "অস্ত্র", "ছুরি", "অপহরণ", "অজ্ঞান",
    )
    private val HIGH = listOf(
        "injured", "hurt", "accident", "robbery", "snatch", "mugging", "gas leak", "leak", "open manhole",
        "child", "children", "school", "hospital", "night", "urgent", "emergency", "danger", "deep", "smoke",
        "আহত", "দুর্ঘটনা", "ছিনতাই", "ডাকাত", "গ্যাস", "খোলা ম্যানহোল", "শিশু", "বাচ্চা", "স্কুল",
        "হাসপাতাল", "রাতে", "জরুরি", "বিপদ", "গভীর", "ধোঁয়া",
    )
    private val MEDIUM = listOf(
        "broken", "dark", "flood", "traffic", "jam", "days", "week", "month", "again", "every day", "smell",
        "ভাঙা", "অন্ধকার", "পানি", "যানজট", "দিন ধরে", "সপ্তাহ", "মাস", "প্রতিদিন", "আবার", "দুর্গন্ধ",
    )

    private val BASE = mapOf(
        Category.Streetlight to Severity.Low,
        Category.Crime to Severity.Medium,
        Category.Accident to Severity.High,
        Category.Hazard to Severity.High,
        Category.Waterlogging to Severity.Medium,
        Category.RoadDamage to Severity.Medium,
        Category.Footpath to Severity.Low,
        Category.Garbage to Severity.Low,
    )

    private val PROMO = Regex(
        "(buy now|discount|free money|lottery|whatsapp me|call now|click here|earn money|বিজ্ঞাপন|অফার|লটারি)",
        RegexOption.IGNORE_CASE,
    )
    private val LINK = Regex("(https?://|www\\.|\\.com\\b|\\.xyz\\b)", RegexOption.IGNORE_CASE)
    private val REPEAT_CHAR = Regex("(.)\\1{5,}")
    private val SPACES = Regex("\\s+")
    private val TEST_WORDS = setOf("test", "testing", "asdf", "qwerty", "hello", "hi", "lol", "xyz", "abc", "demo")

    private val matchers = ConcurrentHashMap<String, Regex>()

    /** ASCII keywords match at word boundaries (so "bus" doesn't match "business"); Bengali uses substring. */
    private fun has(text: String, k: String): Boolean {
        if (k.isEmpty()) return false
        val c = k[0]
        return if (c in 'a'..'z' || c in '0'..'9') {
            matchers.getOrPut(k) {
                // long words / phrases: prefix match ("waterlog" → "waterlogging");
                // short words: whole word + common endings ("bus" ≠ "business", "fight" → "fighting")
                if (k.length >= 6 || k.contains(' ')) Regex("(^|[^a-z0-9])" + Regex.escape(k))
                else Regex("(^|[^a-z0-9])" + Regex.escape(k) + "(s|es|ed|d|ing|er|ers|y)?($|[^a-z0-9])")
            }.containsMatchIn(text)
        } else text.contains(k)
    }

    private fun weight(k: String) = if (k.length >= 7 || k.contains(' ')) 1.6 else 1.0

    fun analyze(
        description: String,
        address: String = "",
        hasPhoto: Boolean = false,
        chosen: Category? = null,
    ): AiResult {
        val text = description.lowercase(Locale.ROOT)

        // ---- category ----
        val raw = Category.entries.associateWith { c ->
            KEYWORDS[c].orEmpty().sumOf { k -> if (has(text, k)) weight(k) else 0.0 }
        }
        val hits = raw.values.sum()
        val scored = raw.toMutableMap()
        if (chosen != null) scored[chosen] = (scored[chosen] ?: 0.0) + 0.75
        val ranked = scored.entries.sortedByDescending { it.value }
        val top = ranked.first()
        val second = ranked.getOrNull(1)?.value ?: 0.0
        val category = if (hits > 0.0) top.key else chosen ?: Category.Hazard

        // ---- severity ----
        val crit = CRITICAL.count { has(text, it) }
        val high = HIGH.count { has(text, it) }
        val med = MEDIUM.count { has(text, it) }
        var level = (BASE[category] ?: Severity.Medium).ordinal
        val kwLevel = when {
            crit > 0 -> Severity.Critical.ordinal
            high > 0 -> Severity.High.ordinal
            med > 0 -> Severity.Medium.ordinal
            else -> 0
        }
        level = max(level, kwLevel)
        if (high >= 3 && level < Severity.Critical.ordinal) level++
        val severity = Severity.entries[level]

        // ---- confidence ----
        var conf = if (hits == 0.0) {
            if (chosen != null) 0.42 else 0.3
        } else {
            val margin = (top.value - second) / (top.value + 1.0)
            0.5 + 0.35 * margin + min(0.08, hits * 0.02)
        }
        if (hasPhoto) conf += 0.04
        if (description.trim().length > 60) conf += 0.04

        // ---- spam ----
        val reasons = spamReasons(description, hits)
        val spam = reasons.size >= 2 || (reasons.isNotEmpty() && hits == 0.0)
        if (spam) conf = min(conf, 0.35)
        conf = conf.coerceIn(0.2, 0.97)

        val (agency, agencyBn) = agencyFor(category, text)
        return AiResult(
            category = category,
            severity = severity,
            agency = agency,
            agencyBn = agencyBn,
            summaryBn = summaryBn(category, severity, agencyBn, description, address),
            confidence = conf,
            spam = spam,
            spamReasons = reasons,
        )
    }

    private fun spamReasons(raw: String, hits: Double): List<String> {
        val t = raw.trim()
        val r = mutableListOf<String>()
        if (t.length < 12) r += "বিবরণ খুব ছোট"
        val meaningful = t.count {
            it.isLetter() || it.isWhitespace() ||
                Character.getType(it) == Character.NON_SPACING_MARK.toInt() ||
                Character.getType(it) == Character.COMBINING_SPACING_MARK.toInt()
        }
        if (t.isNotEmpty() && meaningful.toDouble() / t.length < 0.6) r += "অর্থবোধক লেখা কম"
        if (REPEAT_CHAR.containsMatchIn(t)) r += "একই অক্ষর বারবার"
        if (LINK.containsMatchIn(t)) r += "Link রয়েছে"
        if (PROMO.containsMatchIn(t)) r += "বিজ্ঞাপনের মতো লেখা"
        val words = t.lowercase(Locale.ROOT).split(SPACES).filter { it.isNotBlank() }
        if (words.size >= 6 && words.toSet().size.toDouble() / words.size < 0.4) r += "একই শব্দ বারবার"
        if (words.size in 1..4 && words.any { it.trim('.', '!', '?') in TEST_WORDS }) r += "Test message মনে হচ্ছে"
        if (hits == 0.0 && t.length < 30) r += "কোনো সমস্যার উল্লেখ নেই"
        return r.distinct()
    }

    private fun agencyFor(c: Category, t: String): Pair<String, String> = when (c) {
        Category.Streetlight ->
            "City Corporation (DNCC/DSCC) – Electrical Dept." to "সিটি কর্পোরেশন (DNCC/DSCC) – বিদ্যুৎ বিভাগ"
        Category.Crime ->
            "Bangladesh Police / DMP – 999" to "বাংলাদেশ পুলিশ / ডিএমপি – ৯৯৯"
        Category.Accident ->
            "DMP Traffic Police & Fire Service – 999" to "ডিএমপি ট্রাফিক পুলিশ ও ফায়ার সার্ভিস – ৯৯৯"
        Category.Hazard -> when {
            has(t, "gas") || t.contains("গ্যাস") ->
                "Titas Gas Emergency & Fire Service – 999" to "তিতাস গ্যাস জরুরি সেবা ও ফায়ার সার্ভিস – ৯৯৯"
            has(t, "wire") || has(t, "electric") || has(t, "transformer") || t.contains("তার") ||
                t.contains("বিদ্যুৎ") || t.contains("ট্রান্সফরমার") ->
                "DPDC/DESCO & Fire Service – 999" to "ডিপিডিসি/ডেসকো ও ফায়ার সার্ভিস – ৯৯৯"
            else -> "Fire Service & Civil Defence – 999" to "ফায়ার সার্ভিস ও সিভিল ডিফেন্স – ৯৯৯"
        }
        Category.Waterlogging ->
            "City Corporation (Drainage) & Dhaka WASA" to "সিটি কর্পোরেশন (ড্রেনেজ) ও ঢাকা ওয়াসা"
        Category.RoadDamage ->
            "City Corporation – Engineering Dept. / RHD" to "সিটি কর্পোরেশন – প্রকৌশল বিভাগ / সওজ"
        Category.Footpath ->
            "City Corporation – Engineering & Estate Dept." to "সিটি কর্পোরেশন – প্রকৌশল ও এস্টেট বিভাগ"
        Category.Garbage ->
            "City Corporation – Waste Management Dept." to "সিটি কর্পোরেশন – বর্জ্য ব্যবস্থাপনা বিভাগ"
    }

    private fun summaryBn(c: Category, s: Severity, agencyBn: String, description: String, address: String): String {
        val place = address.split(",").map { it.trim() }.filter { it.isNotEmpty() }.take(2).joinToString(", ")
        val where = if (place.isNotBlank()) "$place এলাকায়" else "চিহ্নিত স্থানে"
        val excerpt = description.trim().replace(SPACES, " ").let { if (it.length > 90) it.take(90) + "…" else it }
        val base = "$where ${c.bn} সংক্রান্ত সমস্যা জানানো হয়েছে। তীব্রতা: ${s.bn}। দায়িত্বপ্রাপ্ত: $agencyBn।"
        return if (excerpt.isNotEmpty()) "$base বিবরণ: “$excerpt”" else base
    }
}
