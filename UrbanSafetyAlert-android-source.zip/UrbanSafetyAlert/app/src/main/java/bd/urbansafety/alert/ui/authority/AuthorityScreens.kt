@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package bd.urbansafety.alert.ui.authority

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import bd.urbansafety.alert.data.Category
import bd.urbansafety.alert.data.Severity
import bd.urbansafety.alert.data.Status
import bd.urbansafety.alert.data.Verification
import bd.urbansafety.alert.ui.auth.AccountMenu
import bd.urbansafety.alert.ui.auth.Session
import bd.urbansafety.alert.ui.components.EmptyState
import bd.urbansafety.alert.ui.components.MessageEffect
import bd.urbansafety.alert.ui.components.NotificationPermissionEffect
import bd.urbansafety.alert.ui.components.ReportCard
import bd.urbansafety.alert.ui.components.ShieldLogo
import bd.urbansafety.alert.ui.components.statusPinColor
import bd.urbansafety.alert.ui.map.ReportsMap
import bd.urbansafety.alert.ui.theme.BrandGradient
import bd.urbansafety.alert.util.CsvExport

@Composable
fun AuthorityHome(session: Session.SignedIn, onSignOut: () -> Unit) {
    val vm: AuthorityViewModel = viewModel(key = "authority-${session.uid}-${session.n}")
    val ctx = LocalContext.current
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var exportMenu by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    MessageEffect(vm.message, snack) { vm.message = null }
    NotificationPermissionEffect()

    val sel = vm.selected
    if (sel != null) {
        BackHandler { vm.selectedId = null }
        ReportDetailScreen(sel, vm, snack, onBack = { vm.selectedId = null })
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    navigationIcon = { ShieldLogo(Modifier.padding(start = 14.dp, end = 6.dp)) },
                    title = {
                        Column {
                            Text("Authority Dashboard", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                            Text(session.email, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    },
                    actions = {
                        Box {
                            IconButton(onClick = { exportMenu = true }) { Icon(Icons.Filled.Download, contentDescription = "Export CSV") }
                            DropdownMenu(expanded = exportMenu, onDismissRequest = { exportMenu = false }) {
                                DropdownMenuItem(
                                    text = { Text("Export filtered (${vm.filtered.size})") },
                                    onClick = { exportMenu = false; exportCsv(ctx, vm, filteredOnly = true) },
                                )
                                DropdownMenuItem(
                                    text = { Text("Export all (${vm.all.size})") },
                                    onClick = { exportMenu = false; exportCsv(ctx, vm, filteredOnly = false) },
                                )
                            }
                        }
                        AccountMenu()
                    },
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Filled.Dashboard, contentDescription = null) }, label = { Text("Overview") },
                    )
                    NavigationBarItem(
                        selected = tab == 1, onClick = { tab = 1 },
                        icon = {
                            BadgedBox(badge = { if (vm.stats.pending > 0) Badge { Text("${vm.stats.pending}") } }) {
                                Icon(Icons.AutoMirrored.Filled.List, contentDescription = null)
                            }
                        },
                        label = { Text("Reports") },
                    )
                    NavigationBarItem(
                        selected = tab == 2, onClick = { tab = 2 },
                        icon = { Icon(Icons.Filled.Map, contentDescription = null) }, label = { Text("Map") },
                    )
                }
            },
            snackbarHost = { SnackbarHost(snack) },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when {
                    vm.loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
                    vm.loadError != null && vm.all.isEmpty() -> EmptyState("⚠️", "Reports load হয়নি", vm.loadError ?: "")
                    tab == 0 -> DashboardScreen(vm, goToList = { tab = 1 })
                    tab == 1 -> ReportsListScreen(vm)
                    else -> ReportsMapScreen(vm)
                }
            }
        }
    }

}

private fun exportCsv(ctx: android.content.Context, vm: AuthorityViewModel, filteredOnly: Boolean) {
    val list = if (filteredOnly) vm.filtered else vm.all
    if (list.isEmpty()) {
        vm.message = "Export করার মতো কোনো report নেই"; return
    }
    runCatching { CsvExport.share(ctx, list) }.onFailure { vm.message = "Export failed: ${it.localizedMessage}" }
}

// ======================= Overview =======================

@Composable
private fun StatTile(label: String, value: Int, accent: Color, modifier: Modifier, onClick: () -> Unit) {
    Card(
        onClick = onClick, modifier = modifier, shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(accent))
                Spacer(Modifier.width(6.dp))
                Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text("$value", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = accent, modifier = Modifier.padding(top = 2.dp))
        }
    }
}

@Composable
fun DashboardScreen(vm: AuthorityViewModel, goToList: () -> Unit) {
    val st = vm.stats
    fun filterAndGo(apply: () -> Unit) {
        vm.clearFilters(); apply(); goToList()
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(Color(0xFF16A34A)))
                Spacer(Modifier.width(6.dp))
                Text("Live — নতুন report সাথে সাথে আসে", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("Total", st.total, MaterialTheme.colorScheme.primary, Modifier.weight(1f)) { filterAndGo {} }
                    StatTile("Pending", st.pending, Color(0xFFEA8A00), Modifier.weight(1f)) { filterAndGo { vm.fStatus = Status.Pending } }
                    StatTile("In Progress", st.inProgress, Color(0xFF1D4ED8), Modifier.weight(1f)) { filterAndGo { vm.fStatus = Status.InProgress } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatTile("Resolved", st.resolved, Color(0xFF16A34A), Modifier.weight(1f)) { filterAndGo { vm.fStatus = Status.Resolved } }
                    StatTile("Critical", st.critical, Color(0xFFDC2626), Modifier.weight(1f)) { filterAndGo { vm.fSeverity = Severity.Critical } }
                    StatTile("Verified", st.verified, Color(0xFF0F766E), Modifier.weight(1f)) { filterAndGo { vm.fVerification = Verification.Verified } }
                }
            }
        }
        item { WeekChart(st.week) }
        if (st.byCategory.isNotEmpty()) item { CategoryBreakdown(st.byCategory, st.total) { c -> filterAndGo { vm.fCategory = c } } }
        if (st.unverified > 0) {
            item {
                Card(
                    onClick = { filterAndGo { vm.fVerification = Verification.Unverified } },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🔎", fontSize = 22.sp)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${st.unverified} reports need verification", fontWeight = FontWeight.SemiBold)
                            Text("Tap to review unverified reports", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
        if (vm.attention.isNotEmpty()) {
            item { Text("Needs attention", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
            items(vm.attention, key = { it.id }) { r -> ReportCard(r, onClick = { vm.selectedId = r.id }, showReporter = true) }
        }
        if (st.total == 0) item { EmptyState("📭", "এখনো কোনো report আসেনি", "Citizen report করলে এখানে live দেখা যাবে।", Modifier.height(260.dp)) }
    }
}

@Composable
private fun WeekChart(week: List<DayCount>) {
    val maxV = (week.maxOfOrNull { it.count } ?: 0).coerceAtLeast(1)
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Last 7 days", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text("${week.sumOf { it.count }} reports", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.fillMaxWidth().height(150.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                week.forEach { d ->
                    Column(
                        Modifier.weight(1f).fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Bottom,
                    ) {
                        Text("${d.count}", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .fillMaxHeight(0.03f + 0.67f * d.count / maxV)
                                .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp))
                                .background(if (d.count > 0) BrandGradient else androidx.compose.ui.graphics.SolidColor(MaterialTheme.colorScheme.outlineVariant)),
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(d.label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryBreakdown(rows: List<Pair<Category, Int>>, total: Int, onPick: (Category) -> Unit) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("By category", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            rows.forEach { (c, n) ->
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).clickable { onPick(c) }.padding(vertical = 2.dp)) {
                    Row {
                        Text("${c.emoji} ${c.id}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        Text("$n", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { if (total == 0) 0f else n.toFloat() / total },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                    )
                }
            }
        }
    }
}

// ======================= Reports list =======================

@Composable
private fun <T : Any> FilterMenu(title: String, selected: T?, options: List<T>, label: (T) -> String, onSelect: (T?) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        FilterChip(
            selected = selected != null,
            onClick = { open = true },
            label = { Text(selected?.let(label) ?: title) },
            trailingIcon = { Icon(Icons.Filled.ArrowDropDown, contentDescription = null) },
        )
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            DropdownMenuItem(text = { Text("All") }, onClick = { onSelect(null); open = false })
            options.forEach { o ->
                DropdownMenuItem(text = { Text(label(o)) }, onClick = { onSelect(o); open = false })
            }
        }
    }
}

@Composable
fun ReportsListScreen(vm: AuthorityViewModel) {
    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = vm.query,
            onValueChange = { vm.query = it },
            placeholder = { Text("Search area / description") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            trailingIcon = {
                if (vm.query.isNotEmpty()) IconButton(onClick = { vm.query = "" }) { Icon(Icons.Filled.Clear, contentDescription = "Clear search") }
            },
            singleLine = true,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp),
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FilterMenu("Category", vm.fCategory, Category.entries, { "${it.emoji} ${it.id}" }) { vm.fCategory = it }
            FilterMenu("Status", vm.fStatus, Status.entries, { it.id }) { vm.fStatus = it }
            FilterMenu("Severity", vm.fSeverity, Severity.entries, { it.id }) { vm.fSeverity = it }
            FilterMenu("Verification", vm.fVerification, Verification.entries, { it.id }) { vm.fVerification = it }
            if (vm.anyFilter) TextButton(onClick = { vm.clearFilters() }) { Text("Clear all") }
        }
        Text(
            "${vm.filtered.size} of ${vm.all.size} reports",
            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        if (vm.filtered.isEmpty()) {
            EmptyState("🔍", "No reports found", if (vm.anyFilter) "Filter বা search বদলে দেখুন।" else "এখনো কোনো report নেই।")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(vm.filtered, key = { it.id }) { r -> ReportCard(r, onClick = { vm.selectedId = r.id }, showReporter = true) }
            }
        }
    }
}

// ======================= Map =======================

@Composable
fun ReportsMapScreen(vm: AuthorityViewModel) {
    Box(Modifier.fillMaxSize()) {
        ReportsMap(vm.filtered, onOpen = { vm.selectedId = it }, modifier = Modifier.fillMaxSize())
        Card(
            modifier = Modifier.align(Alignment.BottomStart).padding(12.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.94f)),
            elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        ) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(
                    "${vm.filtered.count { it.lat != null }} on map" + if (vm.anyFilter) " (filtered)" else "",
                    style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold,
                )
                Status.entries.forEach { s ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(statusPinColor(s)))
                        Spacer(Modifier.width(6.dp))
                        Text(s.id, style = MaterialTheme.typography.labelSmall)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).clip(CircleShape).background(Color(0xFFDC2626)).padding(2.dp).clip(CircleShape).background(Color.White))
                    Spacer(Modifier.width(4.dp))
                    Text("Critical (large, red ring)", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
