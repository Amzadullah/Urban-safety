package bd.urbansafety.alert

import android.app.Application
import bd.urbansafety.alert.data.AppConfig
import bd.urbansafety.alert.util.Notifier
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import org.osmdroid.config.Configuration
import java.io.File

class UrbanSafetyApp : Application() {
    override fun onCreate() {
        super.onCreate()

        // Uses google-services.json if present, otherwise the website's Firebase project.
        if (FirebaseApp.getApps(this).isEmpty()) {
            val options = FirebaseOptions.Builder()
                .setApiKey(AppConfig.FIREBASE_API_KEY)
                .setApplicationId(AppConfig.FIREBASE_APP_ID)
                .setProjectId(AppConfig.FIREBASE_PROJECT_ID)
                .setStorageBucket(AppConfig.FIREBASE_STORAGE_BUCKET)
                .setGcmSenderId(AppConfig.FIREBASE_SENDER_ID)
                .build()
            FirebaseApp.initializeApp(this, options)
        }

        // osmdroid: identify the app to tile servers and keep the tile cache in app storage
        val cfg = Configuration.getInstance()
        cfg.load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        cfg.userAgentValue = BuildConfig.APPLICATION_ID
        cfg.osmdroidBasePath = File(cacheDir, "osmdroid")
        cfg.osmdroidTileCache = File(cacheDir, "osmdroid/tiles")

        Notifier.createChannel(this)
    }
}
