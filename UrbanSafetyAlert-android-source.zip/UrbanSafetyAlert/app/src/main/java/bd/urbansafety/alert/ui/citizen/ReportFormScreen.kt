@file:OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)

package bd.urbansafety.alert.ui.citizen

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import bd.urbansafety.alert.data.Category
import bd.urbansafety.alert.data.Severity
import bd.urbansafety.alert.ui.components.AiCard
import bd.urbansafety.alert.ui.map.LocationPickerMap
import coil.compose.AsyncImage
import java.io.File
import java.util.Locale

private fun newCameraUri(ctx: Context): Uri {
    val dir = File(ctx.cacheDir, "camera").apply { mkdirs() }
    val f = File(dir, "photo-${System.currentTimeMillis()}.jpg")
    return FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", f)
}

private fun hasLocationPermission(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

@Composable
private fun FormSection(step: Int, title: String, content: @Composable ColumnScope.() -> Unit) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(24.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center,
                ) { Text("$step", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.width(10.dp))
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
            }
            content()
        }
    }
}

@Composable
fun ReportFormScreen(vm: CitizenViewModel, onSubmitted: () -> Unit) {
    val ctx = LocalContext.current
    var cameraUri by rememberSaveable { mutableStateOf<Uri?>(null) }
    var spamDialog by remember { mutableStateOf(false) }

    val takePicture = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) vm.photoUri = cameraUri
    }
    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.photoUri = uri
    }
    val locationPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) {
            vm.locateMe()
        } else {
            vm.message = "Location permission দিন, অথবা map-এ tap করে জায়গা বেছে নিন।"
        }
    }
    val locate = {
        if (hasLocationPermission(ctx)) vm.locateMe()
        else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }
    LaunchedEffect(Unit) {
        if (!vm.locationSet && hasLocationPermission(ctx)) vm.locateMe()
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        FormSection(1, "What's the issue?") {
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Category.entries.forEach { c ->
                    FilterChip(
                        selected = vm.category == c,
                        onClick = { vm.category = c },
                        label = { Text("${c.emoji} ${c.id}") },
                    )
                }
            }
        }

        FormSection(2, "Describe it") {
            OutlinedTextField(
                value = vm.description,
                onValueChange = { if (it.length <= 1000) { vm.description = it } },
                placeholder = { Text("কী হয়েছে তা লিখুন… (বাংলা বা English)") },
                minLines = 4,
                supportingText = { Text("${vm.description.length}/1000") },
                modifier = Modifier.fillMaxWidth(),
            )
        }

        FormSection(3, "Photo (optional)") {
            val photo = vm.photoUri
            if (photo != null) {
                Box(Modifier.fillMaxWidth().height(200.dp).clip(RoundedCornerShape(14.dp))) {
                    AsyncImage(model = photo, contentDescription = "Selected photo", contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    IconButton(
                        onClick = { vm.photoUri = null },
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp),
                        colors = IconButtonDefaults.iconButtonColors(containerColor = Color.Black.copy(alpha = 0.55f), contentColor = Color.White),
                    ) { Icon(Icons.Filled.Close, contentDescription = "Remove photo") }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = { val u = newCameraUri(ctx); cameraUri = u; takePicture.launch(u) },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Filled.PhotoCamera, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp)); Text("Camera")
                }
                OutlinedButton(
                    onClick = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.Filled.Image, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp)); Text("Gallery")
                }
            }
        }

        FormSection(4, "Location") {
            Box(Modifier.fillMaxWidth().height(280.dp).clip(RoundedCornerShape(14.dp))) {
                LocationPickerMap(
                    lat = vm.lat, lng = vm.lng, recenterKey = vm.recenter,
                    onPick = { la, ln -> vm.setLocation(la, ln) },
                    modifier = Modifier.fillMaxSize(),
                )
                SmallFloatingActionButton(
                    onClick = { locate() },
                    modifier = Modifier.align(Alignment.BottomEnd).padding(10.dp),
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.onPrimary,
                ) {
                    if (vm.locating) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                    else Icon(Icons.Filled.MyLocation, contentDescription = "Use my location")
                }
            }
            Text(
                "Map-এ tap করুন, অথবা pin চেপে ধরে drag করুন। 📍 বাটনে GPS location।",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            OutlinedTextField(
                value = vm.address,
                onValueChange = { vm.address = it },
                label = { Text("Address") },
                placeholder = { Text("Map-এ জায়গা বাছলে auto-fill হবে") },
                leadingIcon = { Icon(Icons.Filled.LocationOn, contentDescription = null) },
                trailingIcon = { if (vm.addressLoading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                String.format(Locale.US, "%.5f, %.5f", vm.lat, vm.lng) + if (vm.locationSet) "" else "  (default: Dhaka)",
                style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        FormSection(5, "Severity") {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                Severity.entries.forEachIndexed { i, s ->
                    SegmentedButton(
                        selected = vm.severity == s,
                        onClick = { vm.severity = if (vm.severity == s) null else s },
                        shape = SegmentedButtonDefaults.itemShape(index = i, count = Severity.entries.size),
                    ) { Text(s.id, maxLines = 1, style = MaterialTheme.typography.labelMedium) }
                }
            }
            val ai = vm.aiPreview
            Text(
                when {
                    vm.severity != null -> "${vm.severity?.id} (${vm.severity?.bn}) বেছে নেওয়া হয়েছে"
                    ai != null -> "বেছে না নিলে AI suggestion ব্যবহার হবে: ${ai.severity.id}"
                    else -> "বেছে না নিলে AI নিজে severity ঠিক করবে"
                },
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        val ai = vm.aiPreview
        if (ai != null) {
            AiCard(ai, title = "AI preview") {
                val differs = ai.category != vm.category || ai.severity != vm.severity
                if (!ai.isGemini) {
                    OutlinedButton(onClick = { vm.analyzeWithGemini() }, enabled = !vm.geminiBusy) {
                        if (vm.geminiBusy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Filled.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Gemini")
                    }
                }
                FilledTonalButton(onClick = { vm.applyAi() }, enabled = differs) {
                    Text(if (differs) "Apply" else "Applied ✓")
                }
            }
        } else {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "বিবরণ লিখলে AI category, severity, দায়িত্বপ্রাপ্ত সংস্থা ও বাংলা summary suggest করবে।",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }

        vm.submitError?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium) }

        Button(
            onClick = { vm.submit(force = false, onSpam = { spamDialog = true }, onDone = onSubmitted) },
            enabled = !vm.submitting,
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp),
        ) {
            if (vm.submitting) {
                CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                Spacer(Modifier.width(10.dp))
                Text(vm.submitStage)
            } else {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Submit report", fontWeight = FontWeight.SemiBold)
            }
        }
        Spacer(Modifier.height(8.dp))
    }

    if (spamDialog) {
        val reasons = vm.aiPreview?.spamReasons.orEmpty()
        AlertDialog(
            onDismissRequest = { spamDialog = false },
            title = { Text("Possible spam") },
            text = {
                Text(
                    "AI মনে করছে report টি spam হতে পারে" +
                        (if (reasons.isNotEmpty()) " (${reasons.joinToString(", ")})" else "") +
                        "। বিবরণ আরও পরিষ্কার করে লিখলে দ্রুত ব্যবস্থা নেওয়া সহজ হয়।",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    spamDialog = false
                    vm.submit(force = true, onSpam = {}, onDone = onSubmitted)
                }) { Text("Submit anyway") }
            },
            dismissButton = { TextButton(onClick = { spamDialog = false }) { Text("Edit") } },
        )
    }
}
