package bd.urbansafety.alert.ui.map

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import bd.urbansafety.alert.data.AppConfig
import bd.urbansafety.alert.data.Report
import bd.urbansafety.alert.data.Severity
import bd.urbansafety.alert.ui.components.statusPinColor
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.util.MapTileIndex
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker

/** Esri World Street Map — same tiles the website uses, no API key. Esri URLs are z/y/x. */
object EsriStreet : OnlineTileSourceBase(
    "EsriWorldStreet", 1, 19, 256, "",
    arrayOf("https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/"),
    "Tiles © Esri, HERE, Garmin, © OpenStreetMap contributors",
) {
    override fun getTileURLString(pMapTileIndex: Long): String =
        baseUrl + MapTileIndex.getZoom(pMapTileIndex) + "/" + MapTileIndex.getY(pMapTileIndex) + "/" + MapTileIndex.getX(pMapTileIndex)
}

@SuppressLint("ClickableViewAccessibility")
@Composable
private fun rememberMapView(): MapView {
    val ctx = LocalContext.current
    val mv = remember {
        MapView(ctx).apply {
            setTileSource(EsriStreet)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            isTilesScaledToDpi = true
            setMinZoomLevel(3.0)
            setMaxZoomLevel(19.0)
            // keep scrolling parents (forms, sheets) from stealing pan gestures
            setOnTouchListener { v, _ ->
                v.parent?.requestDisallowInterceptTouchEvent(true)
                false
            }
        }
    }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle, mv) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> mv.onResume()
                Lifecycle.Event.ON_PAUSE -> mv.onPause()
                else -> Unit
            }
        }
        lifecycle.addObserver(obs) // replays ON_RESUME if already resumed
        onDispose {
            lifecycle.removeObserver(obs)
            mv.onPause()
            mv.onDetach()
        }
    }
    return mv
}

@Composable
private fun LayerToggle(mv: MapView, modifier: Modifier) {
    var esri by remember { mutableStateOf(true) }
    FilledTonalIconButton(
        onClick = {
            esri = !esri
            mv.setTileSource(if (esri) EsriStreet else TileSourceFactory.MAPNIK)
        },
        modifier = modifier.size(40.dp),
    ) { Icon(Icons.Filled.Layers, contentDescription = "Switch map layer") }
}

/** Tap the map or long-press & drag the pin to choose a location. */
@Composable
fun LocationPickerMap(
    lat: Double,
    lng: Double,
    recenterKey: Int,
    onPick: (Double, Double) -> Unit,
    modifier: Modifier = Modifier,
) {
    val mv = rememberMapView()
    val pick by rememberUpdatedState(onPick)
    val marker = remember(mv) {
        Marker(mv).apply {
            isDraggable = true
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            title = "Issue location"
            position = GeoPoint(lat, lng)
        }
    }
    DisposableEffect(mv) {
        mv.controller.setZoom(15.0)
        mv.controller.setCenter(GeoPoint(lat, lng))
        marker.setOnMarkerDragListener(object : Marker.OnMarkerDragListener {
            override fun onMarkerDrag(m: Marker) {}
            override fun onMarkerDragStart(m: Marker) {}
            override fun onMarkerDragEnd(m: Marker) {
                pick(m.position.latitude, m.position.longitude)
            }
        })
        val events = MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                marker.position = p
                mv.invalidate()
                pick(p.latitude, p.longitude)
                return true
            }

            override fun longPressHelper(p: GeoPoint): Boolean = false
        })
        mv.overlays.add(0, events)
        mv.overlays.add(marker)
        onDispose {
            mv.overlays.remove(events)
            mv.overlays.remove(marker)
        }
    }
    LaunchedEffect(lat, lng) {
        val cur = marker.position
        if (cur.latitude != lat || cur.longitude != lng) {
            marker.position = GeoPoint(lat, lng)
            mv.invalidate()
        }
    }
    LaunchedEffect(recenterKey) {
        if (recenterKey > 0) mv.controller.animateTo(GeoPoint(lat, lng), 17.0, 700L)
    }
    Box(modifier) {
        AndroidView(factory = { mv }, modifier = Modifier.fillMaxSize())
        LayerToggle(mv, Modifier.align(Alignment.TopEnd).padding(8.dp))
    }
}

/** Read-only single pin (report detail). */
@Composable
fun SinglePinMap(lat: Double, lng: Double, modifier: Modifier = Modifier) {
    val mv = rememberMapView()
    DisposableEffect(mv, lat, lng) {
        val p = GeoPoint(lat, lng)
        val m = Marker(mv).apply {
            position = p
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            setOnMarkerClickListener { _, _ -> true }
        }
        mv.overlays.add(m)
        mv.controller.setZoom(16.0)
        mv.controller.setCenter(p)
        mv.invalidate()
        onDispose { mv.overlays.remove(m) }
    }
    Box(modifier) {
        AndroidView(factory = { mv }, modifier = Modifier.fillMaxSize())
        LayerToggle(mv, Modifier.align(Alignment.TopEnd).padding(8.dp))
    }
}

private fun dot(ctx: Context, color: Int, critical: Boolean): Drawable {
    val d = ctx.resources.displayMetrics.density
    val px = ((if (critical) 22 else 17) * d).toInt()
    return GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        setStroke(((if (critical) 3.5f else 2.5f) * d).toInt(), if (critical) 0xFFDC2626.toInt() else android.graphics.Color.WHITE)
        setSize(px, px)
    }
}

/** All reports as status-coloured dots; critical ones are larger with a red ring. */
@Composable
fun ReportsMap(reports: List<Report>, onOpen: (String) -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val mv = rememberMapView()
    val openReport by rememberUpdatedState(onOpen)
    var fitted by remember(mv) { mutableStateOf(false) }

    LaunchedEffect(mv) {
        mv.controller.setZoom(12.0)
        mv.controller.setCenter(GeoPoint(AppConfig.DHAKA_LAT, AppConfig.DHAKA_LNG))
    }
    LaunchedEffect(mv, reports) {
        mv.overlays.removeAll { it is Marker }
        val pts = mutableListOf<GeoPoint>()
        // draw critical last so they sit on top
        reports.sortedBy { if (it.effectiveSeverity == Severity.Critical) 1 else 0 }.forEach { r ->
            val la = r.lat ?: return@forEach
            val ln = r.lng ?: return@forEach
            val p = GeoPoint(la, ln)
            pts += p
            val critical = r.effectiveSeverity == Severity.Critical
            val m = Marker(mv)
            m.position = p
            m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            m.icon = dot(ctx, statusPinColor(r.statusEnum).toArgb(), critical)
            m.title = r.title
            m.snippet = r.address
            m.setOnMarkerClickListener { _, _ -> openReport(r.id); true }
            mv.overlays.add(m)
        }
        mv.invalidate()
        if (!fitted && pts.isNotEmpty()) {
            fitted = true
            val fit = {
                if (pts.size == 1) {
                    mv.controller.setZoom(15.0); mv.controller.setCenter(pts[0])
                } else {
                    val box = BoundingBox.fromGeoPointsSafe(pts)
                    mv.zoomToBoundingBox(box.increaseByScale(1.25f), false, 48)
                }
            }
            if (mv.width > 0 && mv.height > 0) fit() else mv.addOnFirstLayoutListener { _, _, _, _, _ -> fit() }
        }
    }
    Box(modifier) {
        AndroidView(factory = { mv }, modifier = Modifier.fillMaxSize())
        LayerToggle(mv, Modifier.align(Alignment.TopEnd).padding(8.dp))
    }
}
