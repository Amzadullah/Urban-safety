package bd.urbansafety.alert

import bd.urbansafety.alert.ai.SmartAnalyzer
import bd.urbansafety.alert.data.Category
import bd.urbansafety.alert.data.Severity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SmartAnalyzerTest {
    private fun a(t: String, c: Category? = null) = SmartAnalyzer.analyze(t, "Mirpur 10, Dhaka", false, c)

    @Test fun streetlightBangla() {
        val r = a("আমাদের গলির বাতি তিন দিন ধরে নষ্ট, রাতে পুরো অন্ধকার থাকে")
        assertEquals(Category.Streetlight, r.category); assertFalse(r.spam)
        assertTrue(r.severity.ordinal >= Severity.Medium.ordinal)
    }
    @Test fun fireIsCriticalHazard() {
        val r = a("Transformer e aguna lagse, fire and smoke everywhere near the market")
        assertEquals(Category.Hazard, r.category); assertEquals(Severity.Critical, r.severity)
    }
    @Test fun gasLeakAgency() {
        val r = a("রাস্তার পাশে গ্যাস লিক হচ্ছে, তীব্র গন্ধ")
        assertEquals(Category.Hazard, r.category); assertTrue(r.agency.contains("Titas"))
    }
    @Test fun snatchingIsCrime() {
        val r = a("সন্ধ্যায় এখানে প্রতিদিন ছিনতাই হয়, গতকাল এক জনের মোবাইল নিয়ে গেছে")
        assertEquals(Category.Crime, r.category); assertTrue(r.severity.ordinal >= Severity.High.ordinal)
    }
    @Test fun accidentInjured() {
        val r = a("Bus and rickshaw collision, two people injured badly")
        assertEquals(Category.Accident, r.category); assertTrue(r.severity.ordinal >= Severity.High.ordinal)
    }
    @Test fun waterlogging() {
        assertEquals(Category.Waterlogging, a("বৃষ্টির পর হাঁটু পানি জমে থাকে, ড্রেন বন্ধ").category)
    }
    @Test fun pothole() {
        assertEquals(Category.RoadDamage, a("Main road e boro pothole, rickshaw ulte jacche").category)
    }
    @Test fun footpath() {
        assertEquals(Category.Footpath, a("ফুটপাত পুরোটা হকার দখল করে রেখেছে, হাঁটা যায় না").category)
    }
    @Test fun garbage() {
        assertEquals(Category.Garbage, a("রাস্তার মোড়ে ময়লার স্তূপ, দুর্গন্ধে থাকা যায় না").category)
    }
    @Test fun noWordBoundaryFalseHit() {
        // "scar" must not match "car", "business" must not match "bus"
        val r = a("business scar")
        assertTrue(r.spam)
    }
    @Test fun spamDetection() {
        assertTrue(a("test").spam)
        assertTrue(a("aaaaaaaaaaaa").spam)
        assertTrue(a("Buy now discount offer www.cheap.com").spam)
        assertFalse(a("রাস্তায় গর্ত").spam)
    }
    @Test fun bengaliSummary() {
        val r = a("গলির বাতি নষ্ট")
        assertTrue(r.summaryBn.contains("Mirpur 10")); assertTrue(r.summaryBn.contains("স্ট্রিটলাইট"))
        assertTrue(r.confidence in 0.2..0.97)
    }
}
