# Urban Safety Alert — Android app

A native Android app (Kotlin + Jetpack Compose, Material 3). It uses the **same backend as the website**:
Firebase Auth + Firestore (project `urban-safety-alert-b92e2`) and the Netlify functions
`/api/photo` and `/api/geocode` on `polite-centaur-aeea08.netlify.app`. Reports made on the web show up
in the app and the other way round.

Workflow: **Report an issue → Authority reviews it → Work progresses → Issue is resolved.**

## Features

**Citizens**
- Sign up / sign in (email + password), forgot-password email
- 8 categories: Streetlight, Crime, Accident, Hazard, Waterlogging, Road Damage, Footpath, Garbage
- Description, optional photo (camera or gallery; resized to 1600 px, EXIF-rotated, ≤ 5 MB)
- Location by GPS, by tapping the map, or by long-press-dragging the pin, with automatic address lookup
- Severity Low / Medium / High / Critical, or leave it to AI
- Live **AI preview** while typing: category, severity, responsible agency, Bengali summary, confidence, spam check
- "My reports" with a live Pending → In Progress → Resolved timeline, verification result and review note
- Notification when a report's status or verification changes (while the app is running)

**Authorities**
- Live dashboard: totals, pending, in progress, resolved, critical, verified, 7-day activity chart, category breakdown
- "Needs attention" list (high/critical, unresolved)
- Search by area / description, filter by category, status, severity, verification
- Map of all reports (colour = status, large red ring = critical)
- Report detail: photo (tap to enlarge), map pin, open in Google Maps, **Verify / Reject with review note**,
  status update, **re-run AI analysis**
- **Export CSV** (filtered or all) through the Android share sheet (Excel-friendly, Bengali OK)
- Notification for new reports (while the app is running)

**AI assistance:** **Gemini** runs through the website's `/api/ai` Netlify function, which reads the text and the photo.
The API key stays on the server as `GEMINI_API_KEY` and is never put inside the APK. If Gemini isn't available, the app
falls back to the on-device analyzer (`ai/SmartAnalyzer.kt`), which works offline and understands English, Bengali and
Banglish. Suggestions support the reviewer; they never dispatch a response. See `GEMINI-SETUP-BANGLA.md` in the website zip.

## 1. Update Firestore rules (required)

The website's current rules only let authorities change `status`. Verification, review notes and AI re-runs
need the updated rules. Open Firebase Console → Firestore Database → **Rules**, paste [`firestore.rules`](firestore.rules),
then click **Publish**. The website keeps working with these rules.

## 2. Get the APK

### Option A: GitHub (no Android Studio needed)
1. Create a GitHub repo and push this folder to it.
2. GitHub Actions builds it automatically (`.github/workflows/android.yml`).
3. Open **Actions → latest run → Artifacts** and download `UrbanSafetyAlert-debug` (or `-release`).
   Unzip it and install the `.apk` on your phone (allow "Install unknown apps").

### Option B: Android Studio
1. Open this folder in Android Studio (Ladybug or newer). Let Gradle sync.
2. Click **Run ▶** with a phone connected, or use **Build → Build APK(s)**.

### Signing for Play Store
By default, release builds are signed with the debug key so they install directly. For the Play Store, create a
keystore and set `USA_KEYSTORE_FILE`, `USA_KEYSTORE_PASSWORD`, `USA_KEY_ALIAS` and `USA_KEY_PASSWORD`
as environment variables or GitHub secrets.

## Optional: register the Android app in Firebase
The app starts Firebase from code using the website's config, so it works out of the box. For the cleanest setup,
go to Firebase Console → Project settings → **Add app → Android**, enter package `bd.urbansafety.alert`, and download
`google-services.json` into `app/`. The build picks it up automatically.
If you ever restrict the Firebase API key to websites only, the app will need its own Android key.

## Project layout
```
app/src/main/java/bd/urbansafety/alert/
  data/        AppConfig (backend URLs + Firebase), Models, Repo (Firestore, photo upload, geocode)
  ai/          SmartAnalyzer (on-device category/severity/agency/Bengali summary/spam)
  ui/auth      Login / sign-up, session
  ui/citizen   New report form, My reports
  ui/authority Dashboard, Reports list + filters, Map, Report detail (verify / status / AI)
  ui/map       osmdroid maps (Esri street tiles like the website, OSM fallback layer)
  util/        Notifications, CSV export
```

## Security note
As on the website, anyone can choose **Authority** when signing up, and the rules trust the role stored in
`users/{uid}`. Before going public, consider making authority accounts admin-assigned. For example, set the role
only from the Firebase Console and change the `users` rule so clients can't write `role: 'authority'`.
