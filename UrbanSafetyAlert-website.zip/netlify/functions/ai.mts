import { getStore } from "@netlify/blobs";
import type { Config } from "@netlify/functions";
import { CFG } from "../../config.js";

// Gemini AI analysis — API key ta Netlify environment variable e thake (GEMINI_API_KEY), app/website e na.
// POST /api/ai  (Authorization: Bearer <Firebase ID token>)
// body: { description, address?, category?, image?: base64 jpeg, photoUrl?: "/api/photo/..." }

const env = (k: string): string | undefined => (globalThis as any).Netlify?.env?.get(k) ?? (globalThis as any).process?.env?.[k];
const CATS = ["Streetlight", "Crime", "Accident", "Hazard", "Waterlogging", "Road Damage", "Footpath", "Garbage"];
const SEVS = ["Low", "Medium", "High", "Critical"];
const HOURLY_LIMIT = Number(env("AI_HOURLY_LIMIT") || 40);
const MAX_IMAGE_BYTES = 4 * 1024 * 1024;

const SYSTEM = `You are the triage assistant of "Urban Safety Alert", a civic app in Bangladesh (mostly Dhaka).
Citizens report local safety/infrastructure problems in Bengali, English or Banglish. Analyse the report text
(and photo if given) and return JSON only.
- category: one of ${CATS.join(", ")}.
- severity: Low | Medium | High | Critical. Critical = immediate danger to life (fire, live wire, gas leak, serious injury,
  violent crime in progress, collapse). High = risk of injury or crime, blocks movement, near schools/hospitals, at night.
  Medium = significant nuisance needing action within days. Low = minor.
- agency (English) and agencyBn (Bengali): the responsible Bangladeshi body, e.g. City Corporation (DNCC/DSCC) departments,
  Bangladesh Police / DMP (999), DMP Traffic, Fire Service & Civil Defence (999), Titas Gas, DPDC/DESCO, Dhaka WASA, RHD.
  If the location is outside Dhaka, use the relevant local body (City Corporation / Pourashava / Upazila).
- summaryBn: 1–2 sentence neutral Bengali summary for the authority, including place and severity.
- confidence: 0–1, how sure you are about category and severity.
- spam: true if it is not a genuine civic report (test text, ads, gibberish, abuse, unrelated photo).
- spamReasons: short Bengali reasons (empty array if not spam).
Never invent facts that are not in the report. Suggestions support human review; they do not dispatch anyone.`;

const SCHEMA = {
  type: "OBJECT",
  properties: {
    category: { type: "STRING", enum: CATS },
    severity: { type: "STRING", enum: SEVS },
    agency: { type: "STRING" },
    agencyBn: { type: "STRING" },
    summaryBn: { type: "STRING" },
    confidence: { type: "NUMBER" },
    spam: { type: "BOOLEAN" },
    spamReasons: { type: "ARRAY", items: { type: "STRING" } },
  },
  required: ["category", "severity", "agency", "agencyBn", "summaryBn", "confidence", "spam", "spamReasons"],
};

const cors = { "access-control-allow-origin": "*", "access-control-allow-headers": "authorization, content-type" };
const json = (body: unknown, status = 200) => Response.json(body, { status, headers: cors });

async function uidFromToken(req: Request) {
  const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const r = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${CFG.firebase.apiKey}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ idToken: token }),
  });
  if (!r.ok) return null;
  return (await r.json()).users?.[0]?.localId ?? null;
}

// simple per-user hourly limit so the free Gemini quota isn't abused
async function allowed(uid: string) {
  const store = getStore("ai-usage");
  const key = `${uid}/${new Date().toISOString().slice(0, 13)}`;
  const n = Number((await store.get(key)) || 0);
  if (n >= HOURLY_LIMIT) return false;
  await store.set(key, String(n + 1));
  return true;
}

function toBase64(buf: ArrayBuffer) {
  let s = "";
  const b = new Uint8Array(buf);
  for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode(...b.subarray(i, i + 0x8000));
  return btoa(s);
}

export default async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  if (req.method !== "POST") return json({ error: "Method not allowed" }, 405);

  const key = env("GEMINI_API_KEY");
  if (!key) return json({ error: "Gemini কনফিগার করা হয়নি (GEMINI_API_KEY নেই)" }, 503);
  const uid = await uidFromToken(req);
  if (!uid) return json({ error: "Login করুন" }, 401);
  if (!(await allowed(uid))) return json({ error: "এক ঘণ্টায় অনেকবার AI ব্যবহার হয়েছে — পরে চেষ্টা করুন" }, 429);

  const body = await req.json().catch(() => ({} as any));
  const description = String(body.description || "").slice(0, 1500);
  const address = String(body.address || "").slice(0, 300);
  const chosen = CATS.includes(body.category) ? body.category : "";

  const parts: any[] = [{
    text: `Citizen's chosen category: ${chosen || "not chosen"}\nAddress: ${address || "unknown"}\nDescription:\n${description || "(empty)"}`,
  }];

  // photo: either sent inline (before upload) or an already-uploaded /api/photo/... key
  let image: string | null = typeof body.image === "string" ? body.image : null;
  if (!image && typeof body.photoUrl === "string" && body.photoUrl.startsWith("/api/photo/")) {
    const res = await getStore("report-photos").getWithMetadata(decodeURIComponent(body.photoUrl.slice("/api/photo/".length)), { type: "arrayBuffer" });
    if (res && res.data.byteLength <= MAX_IMAGE_BYTES) image = toBase64(res.data);
  }
  if (image && image.length <= (MAX_IMAGE_BYTES * 4) / 3) parts.push({ inline_data: { mime_type: "image/jpeg", data: image } });

  const model = env("GEMINI_MODEL") || "gemini-flash-latest";
  let r: Response;
  try {
    r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM }] },
        contents: [{ role: "user", parts }],
        generationConfig: { responseMimeType: "application/json", responseSchema: SCHEMA },
      }),
      signal: AbortSignal.timeout(9000),
    });
  } catch {
    return json({ error: "Gemini সময়মতো উত্তর দেয়নি" }, 504);
  }
  if (!r.ok) {
    console.error("Gemini error", r.status, (await r.text()).slice(0, 500));
    return json({ error: `Gemini error (${r.status})` }, 502);
  }
  const out = await r.json();
  const text = (out.candidates?.[0]?.content?.parts || []).filter((p: any) => !p.thought).map((p: any) => p.text || "").join("");
  let a: any;
  try { a = JSON.parse(text); } catch { return json({ error: "Gemini উত্তর বোঝা যায়নি" }, 502); }

  return json({
    category: CATS.includes(a.category) ? a.category : chosen || "Hazard",
    severity: SEVS.includes(a.severity) ? a.severity : "Medium",
    agency: String(a.agency || ""),
    agencyBn: String(a.agencyBn || ""),
    summaryBn: String(a.summaryBn || ""),
    confidence: Math.max(0, Math.min(1, Number(a.confidence) || 0.5)),
    spam: Boolean(a.spam),
    spamReasons: Array.isArray(a.spamReasons) ? a.spamReasons.map(String).slice(0, 5) : [],
    model: `gemini:${model}`,
  });
};

export const config: Config = { path: "/api/ai" };
