import type { Config } from "@netlify/functions";

// Nominatim APK (WebView) theke direct call block kore (User-Agent/Referer lage), tai server theke proxy kori
export default async (req: Request) => {
  const u = new URL(req.url);
  const lat = Number(u.searchParams.get("lat")), lng = Number(u.searchParams.get("lng"));
  if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180)
    return Response.json({ error: "Invalid lat/lng" }, { status: 400 });
  const r = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lng}`, {
    headers: { "user-agent": "UrbanSafetyAlert/1.0 (https://polite-centaur-aeea08.netlify.app)", "accept-language": "bn,en" }
  });
  if (!r.ok) return Response.json({ display_name: "" }, { status: 502, headers: { "access-control-allow-origin": "*" } });
  const { display_name = "" } = await r.json();
  return Response.json({ display_name }, { headers: { "access-control-allow-origin": "*", "cache-control": "public, max-age=86400" } });
};

export const config: Config = { path: "/api/geocode" };
