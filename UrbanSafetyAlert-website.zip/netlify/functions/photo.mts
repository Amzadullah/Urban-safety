import { getStore } from "@netlify/blobs";
import type { Config } from "@netlify/functions";
import { CFG } from "../../config.js";

const MAX_BYTES = 5 * 1024 * 1024;

// Firebase ID token verify kore uid ber kori (Identity Toolkit REST, extra SDK lage na)
async function uidFromToken(req: Request) {
  const token = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const r = await fetch(`https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=${CFG.firebase.apiKey}`, {
    method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ idToken: token })
  });
  if (!r.ok) return null;
  return (await r.json()).users?.[0]?.localId ?? null;
}

export default async (req: Request) => {
  const store = getStore("report-photos");

  if (req.method === "GET") {
    const key = decodeURIComponent(new URL(req.url).pathname.replace(/^\/api\/photo\/?/, ""));
    if (!key) return new Response("Not found", { status: 404 });
    const res = await store.getWithMetadata(key, { type: "arrayBuffer" });
    if (!res) return new Response("Not found", { status: 404 });
    return new Response(res.data, {
      headers: { "content-type": String(res.metadata.contentType || "image/jpeg"), "cache-control": "public, max-age=31536000, immutable" }
    });
  }

  if (req.method === "DELETE") {
    // account deletion: remove every photo this user uploaded
    const uid = await uidFromToken(req);
    if (!uid) return Response.json({ error: "Login করুন" }, { status: 401 });
    const { blobs } = await store.list({ prefix: `${uid}/` });
    await Promise.all(blobs.map(b => store.delete(b.key)));
    return Response.json({ deleted: blobs.length });
  }

  if (req.method !== "POST") return new Response("Method not allowed", { status: 405 });
  const uid = await uidFromToken(req);
  if (!uid) return Response.json({ error: "Login করুন" }, { status: 401 });
  const type = req.headers.get("content-type") || "";
  if (!type.startsWith("image/")) return Response.json({ error: "শুধু image upload করা যাবে" }, { status: 400 });
  const body = await req.arrayBuffer();
  if (!body.byteLength) return Response.json({ error: "Photo খালি" }, { status: 400 });
  if (body.byteLength > MAX_BYTES) return Response.json({ error: "Photo 5MB এর বেশি" }, { status: 413 });

  const key = `${uid}/${Date.now()}-${crypto.randomUUID()}`;
  await store.set(key, body, { metadata: { contentType: type } });
  return Response.json({ url: `/api/photo/${key}` });
};

export const config: Config = { path: ["/api/photo", "/api/photo/*"] };
