# Urban Safety Alert – Web (Netlify)
Static site, build step nai, alada backend o lage na. Folder ta Netlify te drag & drop (ba Git connect) korlei hobe.

1. Firebase Console -> Firestore Database create koro (jodi na thake), tarpor **Rules** e `firestore.rules` file er content paste kore Publish koro.
2. Firebase Console -> Authentication -> Settings -> Authorized domains e Netlify domain add koro (`polite-centaur-aeea08.netlify.app`).
3. Photo Netlify Blobs e store hoy (`netlify/functions/photo.mts`, `/api/photo`) — Firebase Storage enable korar dorkar nai.
4. Map OpenStreetMap (Leaflet) diye — kono API key lage na.
5. APK: Capacitor (`npx cap add android`, webDir = ".") ba PWABuilder diye.
