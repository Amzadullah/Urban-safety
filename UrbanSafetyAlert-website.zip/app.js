import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import * as A from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";
import * as F from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import { CFG } from "./config.js";

const app = initializeApp(CFG.firebase);
export const auth = A.getAuth(app), db = F.getFirestore(app);
export { F };
export const CATS = ["Streetlight", "Crime", "Accident", "Hazard"];
export const STATUSES = ["Pending", "In Progress", "Resolved"];
export const ICON = { Streetlight: "💡", Crime: "🚨", Accident: "🚗", Hazard: "⚠️" };
export const DHAKA = { lat: 23.8103, lng: 90.4125 };

export const esc = (s = "") => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
export const badge = s => `<span class="badge s-${s}">${s}</span>`;
export const fmt = d => { const t = d?.toDate ? d.toDate() : d ? new Date(d) : null; return t ? t.toLocaleString("en-GB", { dateStyle: "medium", timeStyle: "short" }) : ""; };
export function toast(m) { const t = document.createElement("div"); t.className = "toast"; t.textContent = m; document.body.append(t); setTimeout(() => t.remove(), 3200); }

// ---- Reports (Firestore direct — alada backend lage na) ----
export async function listReports() {
  const s = await F.getDocs(F.query(F.collection(db, "reports"), F.where("userId", "==", auth.currentUser.uid)));
  const ms = d => d?.toMillis?.() ?? 0;
  return { reports: s.docs.map(d => ({ id: d.id, ...d.data() })).sort((a, b) => ms(b.createdAt) - ms(a.createdAt)) };
}
export const createReport = r => F.addDoc(F.collection(db, "reports"), {
  ...r, status: "Pending", userId: auth.currentUser.uid, userEmail: auth.currentUser.email, createdAt: F.serverTimestamp()
});
export const setStatus = (id, status) => F.updateDoc(F.doc(db, "reports", id), { status, updatedAt: F.serverTimestamp() });

// ---- Auth ----
const home = r => (r === "authority" ? "authority.html" : "report.html");
export async function roleOf(u) { const s = await F.getDoc(F.doc(db, "users", u.uid)); return s.data()?.role === "authority" ? "authority" : "citizen"; }
export async function login(email, pw) { const c = await A.signInWithEmailAndPassword(auth, email, pw); location.href = home(await roleOf(c.user)); }
export async function signup(email, pw, role) {
  const c = await A.createUserWithEmailAndPassword(auth, email, pw);
  await F.setDoc(F.doc(db, "users", c.user.uid), { email, role, createdAt: F.serverTimestamp() });
  location.href = home(role);
}
export const logout = () => A.signOut(auth).then(() => (location.href = "index.html"));
export function guard(need) {
  return new Promise(res => A.onAuthStateChanged(auth, async u => {
    if (!u) return (location.href = "index.html");
    const role = await roleOf(u);
    if (role !== need) return (location.href = home(role));
    res({ user: u, role });
  }));
}
export function redirectIfSignedIn() { A.onAuthStateChanged(auth, async u => { if (u) location.href = home(await roleOf(u)); }); }

// ---- Map (Leaflet + OpenStreetMap, API key lage na) + Photo ----
export function loadMaps() {
  return new Promise((ok, bad) => {
    if (window.L) return ok();
    const css = document.createElement("link");
    css.rel = "stylesheet"; css.href = "vendor/leaflet/leaflet.css";
    document.head.append(css);
    const s = document.createElement("script");
    s.src = "vendor/leaflet/leaflet.js";
    s.onload = () => ok(); s.onerror = () => bad(new Error("Map load হয়নি — internet connection check করুন"));
    document.head.append(s);
  });
}
// APK (Capacitor webDir=".") e file gula phone e local thake (https://localhost / file://), tai "/tiles" phone er nijer
// localhost e chole jay — tokhon live site er full URL use kori
const SITE = "https://polite-centaur-aeea08.netlify.app";
const LOCAL = window.Capacitor?.isNativePlatform?.() || !/^https?:$/.test(location.protocol) || (location.hostname === "localhost" && !location.port);
export const API = LOCAL ? SITE : "";
const ESRI = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}";
export function baseMap(el, center, zoom) {
  L.Icon.Default.imagePath = "vendor/leaflet/images/";
  const m = L.map(el).setView([center.lat, center.lng], zoom);
  // OSM tile server APK (WebView) e "Access blocked" dey, CARTO ekhon "API key required" dey.
  // Esri street map (API key lage na) nijer domain er /tiles/ diye proxy kori, tai WebView/browser sob jaygay kaj kore
  const tiles = L.tileLayer(API + "/tiles/{z}/{y}/{x}", { maxZoom: 19, attribution: "Tiles &copy; Esri, HERE, Garmin, &copy; OpenStreetMap contributors" }).addTo(m);
  // proxy kaj na korle (offline preview, onno domain) direct Esri te switch kori — Esri o API key chay na
  let errs = 0;
  tiles.on("tileerror", () => { if (++errs === 3) tiles.setUrl(ESRI); });
  // WebView e container size late set hoy — size recalc na korle map gray/blank thake
  const fix = () => m.invalidateSize();
  [100, 500, 1500].forEach(t => setTimeout(fix, t));
  addEventListener("resize", fix); addEventListener("orientationchange", fix);
  if (window.ResizeObserver) new ResizeObserver(fix).observe(el);
  return m;
}
export async function reverseGeocode({ lat, lng }) {
  const r = await fetch(`${API}/api/geocode?lat=${lat}&lng=${lng}`);
  return r.ok ? (await r.json()).display_name || "" : "";
}
// Photo Netlify Blobs e jay (/api/photo function diye) — Firebase Storage lage na
function shrink(file, max = 1600) {
  return new Promise(ok => {
    const img = new Image(), u = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height)), c = document.createElement("canvas");
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u);
      c.toBlob(b => ok(b || file), "image/jpeg", 0.82);
    };
    img.onerror = () => { URL.revokeObjectURL(u); ok(file); };
    img.src = u;
  });
}
export async function uploadPhoto(file) {
  const blob = await shrink(file);
  const r = await fetch("/api/photo", {
    method: "POST", body: blob,
    headers: { "content-type": blob.type || "image/jpeg", authorization: `Bearer ${await auth.currentUser.getIdToken()}` }
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || "Photo upload হয়নি");
  return j.url;
}
