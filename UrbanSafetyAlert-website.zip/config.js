// Firebase web config (public — security Firestore rules diye hoy, dekho firestore.rules)
export const CFG = {
  firebase: {
    apiKey: "AIzaSyCehkSya_Ekx4ZUtg7pRRNCaPhFAQS2Ra8",
    authDomain: "urban-safety-alert-b92e2.firebaseapp.com",
    projectId: "urban-safety-alert-b92e2",
    storageBucket: "urban-safety-alert-b92e2.firebasestorage.app",
    messagingSenderId: "272718839314",
    appId: "1:272718839314:web:c4de9fc7731cd611f4a2cb"
  }
};
