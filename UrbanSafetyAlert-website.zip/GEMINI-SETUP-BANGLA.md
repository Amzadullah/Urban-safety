# Gemini AI চালু করা ও App অনলাইনে আনা — ধাপে ধাপে

## ১. Gemini API key নিন
1. https://aistudio.google.com এ যান → Google account দিয়ে login করুন।
2. **Get API key → Create API key** চাপুন। Key টা copy করুন (`AIza...` দিয়ে শুরু)।
3. ⚠️ এই key কাউকে দেবেন না, chat-এ বা code-এ বসাবেন না।

## ২. Netlify-তে key রাখুন
1. https://app.netlify.com → আপনার site (polite-centaur-aeea08) খুলুন।
2. **Site configuration → Environment variables → Add a variable**
   - Key: `GEMINI_API_KEY`  Value: আপনার key  → Scope-এ **Functions** থাকা লাগবে → Save
   - (ঐচ্ছিক) `GEMINI_MODEL` = `gemini-flash-latest` (না দিলে এটাই চলবে)
   - (ঐচ্ছিক) `AI_HOURLY_LIMIT` = `40` (প্রতি user ঘণ্টায় কতবার AI চালাতে পারবে)

## ৩. Website নতুন করে deploy করুন (নতুন `netlify/functions/ai.mts` সহ)
Functions থাকায় শুধু drag & drop এ কাজ নাও করতে পারে। দুইটা উপায়:

**ক) GitHub দিয়ে (সবচেয়ে সহজ ও স্থায়ী)**
1. github.com এ নতুন repo বানান (যেমন `urban-safety-web`) → এই folder এর সব file upload করুন।
2. Netlify → **Site configuration → Build & deploy → Link repository** → ঐ repo বেছে নিন।
   Build command ফাঁকা, Publish directory `.` → Deploy।
3. এরপর GitHub-এ কিছু বদলালেই site আপনা-আপনি update হবে।

**খ) Netlify CLI দিয়ে**
```
npm install -g netlify-cli
netlify login
cd এই-folder
npm install
netlify link        (আপনার site বেছে নিন)
netlify deploy --prod
```

## ৪. Firestore rules update (একবার)
Firebase Console → Firestore Database → **Rules** → `firestore.rules` এর লেখা paste → **Publish**।

## ৫. ঠিকমতো কাজ করছে কিনা দেখুন
Netlify → **Logs → Functions → ai**। App-এ report লিখে **Gemini** বাটন চাপুন — card-এ বেগুনি "Gemini" লেবেল দেখালে কাজ করছে।
Key না থাকলে বা Gemini বন্ধ থাকলে app নিজে থেকেই on-device AI ব্যবহার করে — app কখনো আটকে যাবে না।
